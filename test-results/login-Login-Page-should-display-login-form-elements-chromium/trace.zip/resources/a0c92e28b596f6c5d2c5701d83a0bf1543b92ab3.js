(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7f982bef._.js",
  "static/chunks/78f1f_next_dist_compiled_react-dom_a6c0a65c._.js",
  "static/chunks/78f1f_next_dist_compiled_next-devtools_index_a21f759f.js",
  "static/chunks/78f1f_next_dist_compiled_317584a3._.js",
  "static/chunks/78f1f_next_dist_client_a1ca568c._.js",
  "static/chunks/78f1f_next_dist_0810cdb0._.js",
  "static/chunks/78f1f_@swc_helpers_cjs_91f3b5ad._.js"
],
    source: "entry"
});
