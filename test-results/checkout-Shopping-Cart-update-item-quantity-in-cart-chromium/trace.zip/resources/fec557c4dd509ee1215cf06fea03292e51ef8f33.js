(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/78f1f_e891b038._.js",
  "static/chunks/dev_cs160project_food-delivery-system-cs160_50de2126._.js"
],
    source: "dynamic"
});
