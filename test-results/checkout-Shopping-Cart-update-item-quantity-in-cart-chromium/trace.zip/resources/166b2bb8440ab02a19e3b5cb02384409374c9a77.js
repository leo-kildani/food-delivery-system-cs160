(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:7a92ad [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"604636242395f10bda4ea973bce395e01be131719c":"addToCartAction"},"dev/cs160project/food-delivery-system-cs160/app/(user)/home/actions.ts",""] */ __turbopack_context__.s([
    "addToCartAction",
    ()=>addToCartAction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var addToCartAction = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("604636242395f10bda4ea973bce395e01be131719c", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "addToCartAction"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBQcm9kdWN0LCBQcm9kdWN0U3RhdHVzIH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2Uvc2VydmVyXCI7XG5pbXBvcnQgeyBnZXRDYXJ0SXRlbXMgfSBmcm9tIFwiLi4vY2hlY2tvdXQvYWN0aW9uc1wiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xuaW1wb3J0IHsgT3BlbkFJIH0gZnJvbSBcIm9wZW5haVwiO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuICBsZXQgcGVyc29uYWxfdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgIHdoZXJlOiB7IGF1dGhJZDogdXNlcj8uaWQgfSxcbiAgfSk7XG4gIGlmICghcGVyc29uYWxfdXNlcj8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZCBvciB1c2VyIElEIGlzIHVuZGVmaW5lZFwiKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZVByb2R1Y3RzKCk6IFByb21pc2U8UHJvZHVjdFtdPiB7XG4gIHJldHVybiBhd2FpdCBwcmlzbWEucHJvZHVjdC5maW5kTWFueSh7XG4gICAgd2hlcmU6IHsgc3RhdHVzOiBQcm9kdWN0U3RhdHVzLkFDVElWRSB9LFxuICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpYWxpemVkUHJvZHVjdHMoKTogUHJvbWlzZTxTZXJpYWxpemVkUHJvZHVjdFtdPiB7XG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgcHJpc21hLnByb2R1Y3QuZmluZE1hbnkoe1xuICAgIHdoZXJlOiB7IHN0YXR1czogUHJvZHVjdFN0YXR1cy5BQ1RJVkUgfSxcbiAgfSk7XG5cbiAgcmV0dXJuIHByb2R1Y3RzLm1hcCgocCkgPT4gKHtcbiAgICAuLi5wLFxuICAgIHByaWNlUGVyVW5pdDogcC5wcmljZVBlclVuaXQudG9OdW1iZXIoKSxcbiAgICB3ZWlnaHRQZXJVbml0OiBwLndlaWdodFBlclVuaXQudG9OdW1iZXIoKSxcbiAgfSkpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q2FydElkKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGxldCB1c2VySWQgPSBhd2FpdCBnZXRVc2VySWQoKTtcbiAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgaWYgKGNhcnQgPT0gbnVsbCkge1xuICAgIHJldHVybiAtMTsgLy8gc2hvdWxkIG5ldmVyIGhhcHBlbiBkdWUgdG8gZGF0YWJhc2UgY29uc3RyYWludFxuICB9IGVsc2Uge1xuICAgIHJldHVybiBjYXJ0LmlkO1xuICB9XG59XG5leHBvcnQgdHlwZSBBZGRUb0NhcnRTdGF0ZSA9IHtcbiAgc3VjY2Vzcz86IGJvb2xlYW47XG4gIGVycm9yPzogc3RyaW5nO1xuICBkYXRhPzogYW55O1xufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0NhcnRBY3Rpb24oXG4gIF9wcmV2U3RhdGU6IEFkZFRvQ2FydFN0YXRlLFxuICBmb3JtRGF0YTogRm9ybURhdGFcbik6IFByb21pc2U8QWRkVG9DYXJ0U3RhdGU+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjYXJ0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJjYXJ0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJwcm9kdWN0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBxdWFudGl0eSA9IHBhcnNlSW50KGZvcm1EYXRhLmdldChcInF1YW50aXR5XCIpIGFzIHN0cmluZyk7XG4gICAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICAgIGNvbnNvbGUubG9nKGNhcnRJZCwgdXNlcklkKTtcbiAgICBjb25zdCBhZGRlZEl0ZW0gPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0udXBzZXJ0KHtcbiAgICAgIHdoZXJlOiB7XG4gICAgICAgIGNhcnRJZF9wcm9kdWN0SWQ6IHtcbiAgICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IHtcbiAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxuICAgICAgfSxcbiAgICAgIGNyZWF0ZToge1xuICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0SWQsXG4gICAgICAgIHF1YW50aXR5OiBxdWFudGl0eSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV2YWxpZGF0ZVBhdGgoXCIvaG9tZVwiKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBhZGRlZEl0ZW0gfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHRvIGNhcnQ6XCIsIGVycm9yKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRmFpbGVkIHRvIGFkZCB0byBjYXJ0XCIgfTtcbiAgfVxufVxuXG4vLyAtLS0gU0VSVkVSIEFDVElPTiAtLS1cbmV4cG9ydCB0eXBlIFNlcmlhbGl6ZWRQcm9kdWN0ID0gT21pdDxcbiAgUHJvZHVjdCxcbiAgXCJwcmljZVBlclVuaXRcIiB8IFwid2VpZ2h0UGVyVW5pdFwiXG4+ICYge1xuICBwcmljZVBlclVuaXQ6IG51bWJlcjtcbiAgd2VpZ2h0UGVyVW5pdDogbnVtYmVyO1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBDYXJ0SXRlbSB7XG4gIGNhcnRJZDogbnVtYmVyO1xuICBpZDogbnVtYmVyO1xuICBwcm9kdWN0SWQ6IG51bWJlcjtcbiAgcXVhbnRpdHk6IG51bWJlcjtcbiAgcHJvZHVjdDogU2VyaWFsaXplZFByb2R1Y3Q7XG59XG5cbi8vIC0tLSBDSEFUQk9UIEFJIC0tLVxuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSSh7XG4gIGFwaUtleTogcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVksXG59KTtcblxudHlwZSBDaGF0TWVzc2FnZSA9IHtcbiAgcm9sZTogXCJ1c2VyXCIgfCBcImFzc2lzdGFudFwiO1xuICBjb250ZW50OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZENoYXRNZXNzYWdlKG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFtZXNzYWdlcyB8fCAhQXJyYXkuaXNBcnJheShtZXNzYWdlcykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbWVzc2FnZXMgZm9ybWF0XCIpO1xuICAgIH1cblxuICAgIGlmICghcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk9wZW5BSSBBUEkga2V5IG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgZ2V0QWN0aXZlUHJvZHVjdHMgZnVuY3Rpb25cbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IGdldEFjdGl2ZVByb2R1Y3RzKCk7XG5cbiAgICAvLyBGb3JtYXQgYWxsIHByb2R1Y3RzIGluIERCIGZvciB0aGUgQUkgY29udGV4dCB3aXRoIElELCBuYW1lLCBhbmQgaW5ncmVkaWVudHNcbiAgICBjb25zdCBwcm9kdWN0c0NvbnRleHQgPVxuICAgICAgcHJvZHVjdHNcbiAgICAgICAgPy5tYXAoXG4gICAgICAgICAgKHApID0+IGBJRDogJHtwLmlkfSwgTmFtZTogJHtwLm5hbWV9LCBJbmdyZWRpZW50czogJHtwLmRlc2NyaXB0aW9ufWBcbiAgICAgICAgKVxuICAgICAgICAuam9pbihcIlxcblwiKSB8fCBcIk5vIHByb2R1Y3RzIGF2YWlsYWJsZVwiO1xuXG4gICAgLy8gSW4gc2VuZENoYXRNZXNzYWdlIGZ1bmN0aW9uLCB1cGRhdGUgdGhlIFNZU1RFTV9QUk9NUFQ6XG4gICAgY29uc3QgU1lTVEVNX1BST01QVCA9IGBZb3UgYXJlIGFuIEFJIGFzc2lzdGFudCBmb3IgYSBmb29kIGRlbGl2ZXJ5IHNlcnZpY2UgdGhhdCBoZWxwcyB1c2VycyBmaW5kIGluZ3JlZGllbnRzLlxuXG5BdmFpbGFibGUgUHJvZHVjdHM6XG4ke3Byb2R1Y3RzQ29udGV4dH1cblxuV2hlbiBhIHVzZXIgYXNrcyBhYm91dCBpbmdyZWRpZW50cyBmb3IgYSByZWNpcGUgb3IgbWVhbCwgYW5hbHl6ZSB0aGVpciByZXF1ZXN0IGFuZCByZXNwb25kIHdpdGggYSBKU09OIG9iamVjdCBjb250YWluaW5nIGEgXCJwcm9kdWN0c1wiIGFycmF5LiBFYWNoIHByb2R1Y3Qgc2hvdWxkIGluY2x1ZGU6XG4tIHByb2R1Y3RJRDogdGhlIHByb2R1Y3QgSUQgbnVtYmVyXG4tIHByb2R1Y3ROYW1lOiB0aGUgcHJvZHVjdCBuYW1lXG4tIHF1YW50aXR5OiBlc3RpbWF0ZWQgcXVhbnRpdHkgbmVlZGVkIChhcyBhIG51bWJlcilcblxuRXhhbXBsZSByZXNwb25zZSBmb3JtYXQ6XG57XG4gIFwicHJvZHVjdHNcIjogW1xuICAgIHtcInByb2R1Y3RJRFwiOiAxLCBcInByb2R1Y3ROYW1lXCI6IFwiVG9tYXRvZXNcIiwgXCJxdWFudGl0eVwiOiAzfSxcbiAgICB7XCJwcm9kdWN0SURcIjogNSwgXCJwcm9kdWN0TmFtZVwiOiBcIk9uaW9uc1wiLCBcInF1YW50aXR5XCI6IDJ9XG4gIF1cbn1cblxuSU1QT1JUQU5UOlxuLSBSZXNwb25kIE9OTFkgd2l0aCB0aGUgSlNPTiBvYmplY3QgY29udGFpbmluZyBhIFwicHJvZHVjdHNcIiBhcnJheSwgbm8gYWRkaXRpb25hbCB0ZXh0XG4tIEJhc2UgeW91ciByZXNwb25zZSBvbiB0aGUgYXZhaWxhYmxlIHByb2R1Y3RzIGxpc3RlZCBhYm92ZVxuLSBJZiB0aGUgdXNlciBhc2tzIGEgbm9uLWluZ3JlZGllbnQgcXVlc3Rpb24sIHJlc3BvbmQgd2l0aDoge1wicHJvZHVjdHNcIjogW119XG4tIEVzdGltYXRlIHJlYXNvbmFibGUgcXVhbnRpdGllcyBiYXNlZCBvbiB0aGUgcmVjaXBlIG9yIHJlcXVlc3RgO1xuXG4gICAgY29uc3Qgb3BlbmFpTWVzc2FnZXMgPSBtZXNzYWdlcy5tYXAoKG1zZykgPT4gKHtcbiAgICAgIHJvbGU6IG1zZy5yb2xlIGFzIFwidXNlclwiIHwgXCJhc3Npc3RhbnRcIixcbiAgICAgIGNvbnRlbnQ6IG1zZy5jb250ZW50LFxuICAgIH0pKTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcbiAgICAgIG1vZGVsOiBcImdwdC00by1taW5pXCIsXG4gICAgICBtZXNzYWdlczogW3sgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogU1lTVEVNX1BST01QVCB9LCAuLi5vcGVuYWlNZXNzYWdlc10sXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXG4gICAgICB0ZW1wZXJhdHVyZTogMC43LFxuICAgICAgcmVzcG9uc2VfZm9ybWF0OiB7IHR5cGU6IFwianNvbl9vYmplY3RcIiB9LFxuICAgIH0pO1xuXG4gICAgLy9KU09OX09CSkVDVFxuICAgIGNvbnN0IGFzc2lzdGFudE1lc3NhZ2UgPSByZXNwb25zZS5jaG9pY2VzWzBdLm1lc3NhZ2UuY29udGVudDtcblxuICAgIHJldHVybiB7XG4gICAgICBjb250ZW50OiBhc3Npc3RhbnRNZXNzYWdlLCAvL3JldHVybiBhIEpTT05fT0JKRUNUIG9mIHN1Z2dlc3RlZCBwcm9kdWN0c1xuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkNoYXQgQVBJIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiK1VBc0RzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardAction",
    ()=>CardAction,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/lib/utils.ts [app-client] (ecmascript)");
;
;
function Card(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Card;
function CardHeader(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c1 = CardHeader;
function CardTitle(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("leading-none font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c2 = CardTitle;
function CardDescription(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_c3 = CardDescription;
function CardAction(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-action",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_c4 = CardAction;
function CardContent(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 66,
        columnNumber: 5
    }, this);
}
_c5 = CardContent;
function CardFooter(param) {
    let { className, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center px-6 [.border-t]:pt-6", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
_c6 = CardFooter;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6;
__turbopack_context__.k.register(_c, "Card");
__turbopack_context__.k.register(_c1, "CardHeader");
__turbopack_context__.k.register(_c2, "CardTitle");
__turbopack_context__.k.register(_c3, "CardDescription");
__turbopack_context__.k.register(_c4, "CardAction");
__turbopack_context__.k.register(_c5, "CardContent");
__turbopack_context__.k.register(_c6, "CardFooter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/components/ui/input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
function Input(param) {
    let { className, type, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", "focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]", "aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/input.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Input;
;
var _c;
__turbopack_context__.k.register(_c, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ProductCard",
    ()=>ProductCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$7a92ad__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:7a92ad [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ProductCard(param) {
    let { product, isInCart, quantity, cartId, onCartChange } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [q, setQuantity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(quantity ? quantity : 1);
    const [quantityChanged, setQuantityChanged] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleQuantityChange = (e)=>{
        setQuantity(parseInt(e.target.value) || 1);
        setQuantityChanged(true);
    };
    const [state, formAction, isPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"])({
        "ProductCard.useActionState": async (prevState, formData)=>{
            const newState = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$7a92ad__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["addToCartAction"])(prevState, formData);
            if (newState.success) {
                setQuantityChanged(false);
                // Trigger cart refresh callback
                if (onCartChange) {
                    onCartChange();
                }
            }
            return newState;
        }
    }["ProductCard.useActionState"], {});
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
        className: "border-black/10 hover:shadow-lg transition-shadow h-full flex flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                className: "pb-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start justify-between gap-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold leading-tight flex-1",
                            children: product.name
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "inline-block bg-blue-100 text-blue-800 text-xs font-semibold px-3 py-1 rounded-full w-fit",
                        children: product.category
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                className: "flex-1 flex flex-col justify-between space-y-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-600 line-clamp-2",
                            children: product.description
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 gap-3 pt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-green-50 rounded-lg p-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600",
                                            children: "Price per Unit"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 73,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg font-bold text-green-600",
                                            children: [
                                                "$",
                                                product.pricePerUnit.toFixed(2)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 74,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 72,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-blue-50 rounded-lg p-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs text-gray-600",
                                            children: "Weight per Unit"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 80,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg font-bold text-blue-600",
                                            children: [
                                                product.weightPerUnit.toFixed(3),
                                                " lbs"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 81,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 79,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-orange-50 rounded-lg p-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-600",
                                    children: "Available"
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 88,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-lg font-bold text-orange-600",
                                    children: [
                                        product.quantityOnHand,
                                        " in stock"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 89,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            action: formAction,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "hidden",
                                    name: "cartId",
                                    value: cartId
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 95,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "hidden",
                                    name: "productId",
                                    value: product.id
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 96,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "hidden",
                                    name: "quantity",
                                    value: q
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 97,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-end justify-center gap-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    htmlFor: "quantity",
                                                    className: "block text-xs font-medium text-gray-700 mb-1",
                                                    children: "Quantity"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                    type: "number",
                                                    id: "quantity",
                                                    min: 1,
                                                    max: product.quantityOnHand,
                                                    value: q,
                                                    onChange: handleQuantityChange,
                                                    className: "w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                                    lineNumber: 106,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 99,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "pt-5",
                                            children: !isInCart ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                type: "submit",
                                                children: isPending ? "Adding To Cart..." : "Add To Cart"
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                                lineNumber: 118,
                                                columnNumber: 19
                                            }, this) : quantityChanged ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                type: "submit",
                                                children: isPending ? "Updating Cart..." : "Update Cart"
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                                lineNumber: 122,
                                                columnNumber: 19
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                type: "button",
                                                className: "border border-gray-300 bg-transparent text-gray-700",
                                                disabled: isPending,
                                                onClick: ()=>router.push("/shopping-cart"),
                                                children: isPending ? "Updating Cart..." : "In Cart"
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                                lineNumber: 126,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                            lineNumber: 116,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                                    lineNumber: 98,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(ProductCard, "UupBP1c8vKoMbYCpL7KogKLvIFI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"]
    ];
});
_c = ProductCard;
var _c;
__turbopack_context__.k.register(_c, "ProductCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/hooks/use-set-search-param.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useSetSearchParam",
    ()=>useSetSearchParam
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useSetSearchParam() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    return function(updater) {
        let { replace = true } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        const sp = new URLSearchParams(searchParams.toString());
        updater(sp);
        const href = sp.toString() ? "".concat(pathname, "?").concat(sp) : pathname;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startTransition"])(()=>{
            replace ? router.replace(href) : router.push(href);
        });
    };
}
_s(useSetSearchParam, "66hrdMMH0WyruZN7frcpeuU7V/k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductSearchGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/use-debounce/dist/index.module.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$fuse$2e$js$2f$dist$2f$fuse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/fuse.js/dist/fuse.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$hooks$2f$use$2d$set$2d$search$2d$param$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/hooks/use-set-search-param.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const PAGE_SIZE = 9;
function ProductSearchGrid(param) {
    let { products, cart, cartId } = param;
    _s();
    const [userQuery, setUserQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [debounced] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebounce"])(userQuery, 250);
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const setSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$hooks$2f$use$2d$set$2d$search$2d$param$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetSearchParam"])();
    // check if a certain product is already in cart and keep a list of that
    let cartItemMap = new Map();
    cart.forEach((cartItem)=>{
        cartItemMap.set(cartItem.product.id, cartItem.quantity);
    });
    const fuse = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductSearchGrid.useMemo[fuse]": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$fuse$2e$js$2f$dist$2f$fuse$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](products, {
                keys: [
                    "name",
                    "category"
                ],
                threshold: 0.2,
                includeScore: true,
                includeMatches: true,
                ignoreLocation: true,
                minMatchCharLength: 1
            })
    }["ProductSearchGrid.useMemo[fuse]"], [
        products
    ]);
    const raw = debounced ? fuse.search(debounced).map((p)=>p.item) : products;
    var _searchParams_get;
    // --- page from URL ---
    const rawPage = Number((_searchParams_get = searchParams.get("page")) !== null && _searchParams_get !== void 0 ? _searchParams_get : "1");
    const requestedPage = Number.isFinite(rawPage) && rawPage >= 1 ? Math.floor(rawPage) : 1;
    const totalPages = Math.max(1, Math.ceil(products.length / PAGE_SIZE));
    const currentPage = Math.min(requestedPage, totalPages);
    const start = (currentPage - 1) * PAGE_SIZE;
    const pageItems = raw.slice(start, start + PAGE_SIZE);
    // --- page setter using setSearchParam hook ---
    const setPage = function(nextPage) {
        let { replace = false } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        setSearch((sp)=>{
            if (nextPage <= 1) sp.delete("page");
            else sp.set("page", String(nextPage));
        }, {
            replace
        });
    };
    // handle product search bar
    const handleSearchChange = (q)=>{
        setUserQuery(q);
        // keep URL accurate and reset to page 1
        setSearch((sp)=>{
            sp.delete("page");
        }, {
            replace: true
        });
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "product-search",
                        className: "block text-sm font-medium",
                        children: "Search"
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        id: "product-search",
                        value: userQuery,
                        onChange: (e)=>handleSearchChange(e.target.value),
                        placeholder: "Search products…",
                        className: "mt-1 w-full rounded border px-3 py-2",
                        "aria-label": "Search products"
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            debounced && raw.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-500",
                children: [
                    "No results for “",
                    debounced,
                    "”."
                ]
            }, void 0, true, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                lineNumber: 100,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3",
                children: pageItems.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                        product: product,
                        isInCart: cartItemMap.has(product.id),
                        quantity: cartItemMap.get(product.id),
                        cartId: cartId
                    }, product.id, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                        lineNumber: 105,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            totalPages > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-center mt-6 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setPage(currentPage - 1),
                        disabled: currentPage === 1,
                        className: "rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50",
                        children: "Previous"
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                        lineNumber: 118,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setPage(currentPage + 1),
                        disabled: currentPage === totalPages,
                        className: "rounded border border-gray-300 px-3 py-1 text-sm disabled:opacity-50",
                        children: "Next"
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
                lineNumber: 117,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-search-grid.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(ProductSearchGrid, "Mv1zxdCxui5s/rnKEHaFms8wY2c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebounce"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$hooks$2f$use$2d$set$2d$search$2d$param$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSetSearchParam"]
    ];
});
_c = ProductSearchGrid;
var _c;
__turbopack_context__.k.register(_c, "ProductSearchGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ScrollArea",
    ()=>ScrollArea,
    "ScrollBar",
    ()=>ScrollBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/@radix-ui/react-scroll-area/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/lib/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
function ScrollArea(param) {
    let { className, children, ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "scroll-area",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("relative", className),
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
                "data-slot": "scroll-area-viewport",
                className: "focus-visible:ring-ring/50 size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:outline-1",
                children: children
            }, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ScrollBar, {}, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Corner"], {}, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = ScrollArea;
function ScrollBar(param) {
    let { className, orientation = "vertical", ...props } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollAreaScrollbar"], {
        "data-slot": "scroll-area-scrollbar",
        orientation: orientation,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex touch-none p-px transition-colors select-none", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent", className),
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$scroll$2d$area$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollAreaThumb"], {
            "data-slot": "scroll-area-thumb",
            className: "bg-border relative flex-1 rounded-full"
        }, void 0, false, {
            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
            lineNumber: 50,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_c1 = ScrollBar;
;
var _c, _c1;
__turbopack_context__.k.register(_c, "ScrollArea");
__turbopack_context__.k.register(_c1, "ScrollBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:499dce [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4081277433a3de2f1583f1301bf970c9a3239eeb2f":"sendChatMessage"},"dev/cs160project/food-delivery-system-cs160/app/(user)/home/actions.ts",""] */ __turbopack_context__.s([
    "sendChatMessage",
    ()=>sendChatMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var sendChatMessage = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4081277433a3de2f1583f1301bf970c9a3239eeb2f", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "sendChatMessage"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBQcm9kdWN0LCBQcm9kdWN0U3RhdHVzIH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2Uvc2VydmVyXCI7XG5pbXBvcnQgeyBnZXRDYXJ0SXRlbXMgfSBmcm9tIFwiLi4vY2hlY2tvdXQvYWN0aW9uc1wiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xuaW1wb3J0IHsgT3BlbkFJIH0gZnJvbSBcIm9wZW5haVwiO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuICBsZXQgcGVyc29uYWxfdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgIHdoZXJlOiB7IGF1dGhJZDogdXNlcj8uaWQgfSxcbiAgfSk7XG4gIGlmICghcGVyc29uYWxfdXNlcj8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZCBvciB1c2VyIElEIGlzIHVuZGVmaW5lZFwiKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZVByb2R1Y3RzKCk6IFByb21pc2U8UHJvZHVjdFtdPiB7XG4gIHJldHVybiBhd2FpdCBwcmlzbWEucHJvZHVjdC5maW5kTWFueSh7XG4gICAgd2hlcmU6IHsgc3RhdHVzOiBQcm9kdWN0U3RhdHVzLkFDVElWRSB9LFxuICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpYWxpemVkUHJvZHVjdHMoKTogUHJvbWlzZTxTZXJpYWxpemVkUHJvZHVjdFtdPiB7XG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgcHJpc21hLnByb2R1Y3QuZmluZE1hbnkoe1xuICAgIHdoZXJlOiB7IHN0YXR1czogUHJvZHVjdFN0YXR1cy5BQ1RJVkUgfSxcbiAgfSk7XG5cbiAgcmV0dXJuIHByb2R1Y3RzLm1hcCgocCkgPT4gKHtcbiAgICAuLi5wLFxuICAgIHByaWNlUGVyVW5pdDogcC5wcmljZVBlclVuaXQudG9OdW1iZXIoKSxcbiAgICB3ZWlnaHRQZXJVbml0OiBwLndlaWdodFBlclVuaXQudG9OdW1iZXIoKSxcbiAgfSkpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q2FydElkKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGxldCB1c2VySWQgPSBhd2FpdCBnZXRVc2VySWQoKTtcbiAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgaWYgKGNhcnQgPT0gbnVsbCkge1xuICAgIHJldHVybiAtMTsgLy8gc2hvdWxkIG5ldmVyIGhhcHBlbiBkdWUgdG8gZGF0YWJhc2UgY29uc3RyYWludFxuICB9IGVsc2Uge1xuICAgIHJldHVybiBjYXJ0LmlkO1xuICB9XG59XG5leHBvcnQgdHlwZSBBZGRUb0NhcnRTdGF0ZSA9IHtcbiAgc3VjY2Vzcz86IGJvb2xlYW47XG4gIGVycm9yPzogc3RyaW5nO1xuICBkYXRhPzogYW55O1xufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0NhcnRBY3Rpb24oXG4gIF9wcmV2U3RhdGU6IEFkZFRvQ2FydFN0YXRlLFxuICBmb3JtRGF0YTogRm9ybURhdGFcbik6IFByb21pc2U8QWRkVG9DYXJ0U3RhdGU+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjYXJ0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJjYXJ0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJwcm9kdWN0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBxdWFudGl0eSA9IHBhcnNlSW50KGZvcm1EYXRhLmdldChcInF1YW50aXR5XCIpIGFzIHN0cmluZyk7XG4gICAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICAgIGNvbnNvbGUubG9nKGNhcnRJZCwgdXNlcklkKTtcbiAgICBjb25zdCBhZGRlZEl0ZW0gPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0udXBzZXJ0KHtcbiAgICAgIHdoZXJlOiB7XG4gICAgICAgIGNhcnRJZF9wcm9kdWN0SWQ6IHtcbiAgICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IHtcbiAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxuICAgICAgfSxcbiAgICAgIGNyZWF0ZToge1xuICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0SWQsXG4gICAgICAgIHF1YW50aXR5OiBxdWFudGl0eSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV2YWxpZGF0ZVBhdGgoXCIvaG9tZVwiKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBhZGRlZEl0ZW0gfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHRvIGNhcnQ6XCIsIGVycm9yKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRmFpbGVkIHRvIGFkZCB0byBjYXJ0XCIgfTtcbiAgfVxufVxuXG4vLyAtLS0gU0VSVkVSIEFDVElPTiAtLS1cbmV4cG9ydCB0eXBlIFNlcmlhbGl6ZWRQcm9kdWN0ID0gT21pdDxcbiAgUHJvZHVjdCxcbiAgXCJwcmljZVBlclVuaXRcIiB8IFwid2VpZ2h0UGVyVW5pdFwiXG4+ICYge1xuICBwcmljZVBlclVuaXQ6IG51bWJlcjtcbiAgd2VpZ2h0UGVyVW5pdDogbnVtYmVyO1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBDYXJ0SXRlbSB7XG4gIGNhcnRJZDogbnVtYmVyO1xuICBpZDogbnVtYmVyO1xuICBwcm9kdWN0SWQ6IG51bWJlcjtcbiAgcXVhbnRpdHk6IG51bWJlcjtcbiAgcHJvZHVjdDogU2VyaWFsaXplZFByb2R1Y3Q7XG59XG5cbi8vIC0tLSBDSEFUQk9UIEFJIC0tLVxuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSSh7XG4gIGFwaUtleTogcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVksXG59KTtcblxudHlwZSBDaGF0TWVzc2FnZSA9IHtcbiAgcm9sZTogXCJ1c2VyXCIgfCBcImFzc2lzdGFudFwiO1xuICBjb250ZW50OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZENoYXRNZXNzYWdlKG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFtZXNzYWdlcyB8fCAhQXJyYXkuaXNBcnJheShtZXNzYWdlcykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbWVzc2FnZXMgZm9ybWF0XCIpO1xuICAgIH1cblxuICAgIGlmICghcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk9wZW5BSSBBUEkga2V5IG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgZ2V0QWN0aXZlUHJvZHVjdHMgZnVuY3Rpb25cbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IGdldEFjdGl2ZVByb2R1Y3RzKCk7XG5cbiAgICAvLyBGb3JtYXQgYWxsIHByb2R1Y3RzIGluIERCIGZvciB0aGUgQUkgY29udGV4dCB3aXRoIElELCBuYW1lLCBhbmQgaW5ncmVkaWVudHNcbiAgICBjb25zdCBwcm9kdWN0c0NvbnRleHQgPVxuICAgICAgcHJvZHVjdHNcbiAgICAgICAgPy5tYXAoXG4gICAgICAgICAgKHApID0+IGBJRDogJHtwLmlkfSwgTmFtZTogJHtwLm5hbWV9LCBJbmdyZWRpZW50czogJHtwLmRlc2NyaXB0aW9ufWBcbiAgICAgICAgKVxuICAgICAgICAuam9pbihcIlxcblwiKSB8fCBcIk5vIHByb2R1Y3RzIGF2YWlsYWJsZVwiO1xuXG4gICAgLy8gSW4gc2VuZENoYXRNZXNzYWdlIGZ1bmN0aW9uLCB1cGRhdGUgdGhlIFNZU1RFTV9QUk9NUFQ6XG4gICAgY29uc3QgU1lTVEVNX1BST01QVCA9IGBZb3UgYXJlIGFuIEFJIGFzc2lzdGFudCBmb3IgYSBmb29kIGRlbGl2ZXJ5IHNlcnZpY2UgdGhhdCBoZWxwcyB1c2VycyBmaW5kIGluZ3JlZGllbnRzLlxuXG5BdmFpbGFibGUgUHJvZHVjdHM6XG4ke3Byb2R1Y3RzQ29udGV4dH1cblxuV2hlbiBhIHVzZXIgYXNrcyBhYm91dCBpbmdyZWRpZW50cyBmb3IgYSByZWNpcGUgb3IgbWVhbCwgYW5hbHl6ZSB0aGVpciByZXF1ZXN0IGFuZCByZXNwb25kIHdpdGggYSBKU09OIG9iamVjdCBjb250YWluaW5nIGEgXCJwcm9kdWN0c1wiIGFycmF5LiBFYWNoIHByb2R1Y3Qgc2hvdWxkIGluY2x1ZGU6XG4tIHByb2R1Y3RJRDogdGhlIHByb2R1Y3QgSUQgbnVtYmVyXG4tIHByb2R1Y3ROYW1lOiB0aGUgcHJvZHVjdCBuYW1lXG4tIHF1YW50aXR5OiBlc3RpbWF0ZWQgcXVhbnRpdHkgbmVlZGVkIChhcyBhIG51bWJlcilcblxuRXhhbXBsZSByZXNwb25zZSBmb3JtYXQ6XG57XG4gIFwicHJvZHVjdHNcIjogW1xuICAgIHtcInByb2R1Y3RJRFwiOiAxLCBcInByb2R1Y3ROYW1lXCI6IFwiVG9tYXRvZXNcIiwgXCJxdWFudGl0eVwiOiAzfSxcbiAgICB7XCJwcm9kdWN0SURcIjogNSwgXCJwcm9kdWN0TmFtZVwiOiBcIk9uaW9uc1wiLCBcInF1YW50aXR5XCI6IDJ9XG4gIF1cbn1cblxuSU1QT1JUQU5UOlxuLSBSZXNwb25kIE9OTFkgd2l0aCB0aGUgSlNPTiBvYmplY3QgY29udGFpbmluZyBhIFwicHJvZHVjdHNcIiBhcnJheSwgbm8gYWRkaXRpb25hbCB0ZXh0XG4tIEJhc2UgeW91ciByZXNwb25zZSBvbiB0aGUgYXZhaWxhYmxlIHByb2R1Y3RzIGxpc3RlZCBhYm92ZVxuLSBJZiB0aGUgdXNlciBhc2tzIGEgbm9uLWluZ3JlZGllbnQgcXVlc3Rpb24sIHJlc3BvbmQgd2l0aDoge1wicHJvZHVjdHNcIjogW119XG4tIEVzdGltYXRlIHJlYXNvbmFibGUgcXVhbnRpdGllcyBiYXNlZCBvbiB0aGUgcmVjaXBlIG9yIHJlcXVlc3RgO1xuXG4gICAgY29uc3Qgb3BlbmFpTWVzc2FnZXMgPSBtZXNzYWdlcy5tYXAoKG1zZykgPT4gKHtcbiAgICAgIHJvbGU6IG1zZy5yb2xlIGFzIFwidXNlclwiIHwgXCJhc3Npc3RhbnRcIixcbiAgICAgIGNvbnRlbnQ6IG1zZy5jb250ZW50LFxuICAgIH0pKTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcbiAgICAgIG1vZGVsOiBcImdwdC00by1taW5pXCIsXG4gICAgICBtZXNzYWdlczogW3sgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogU1lTVEVNX1BST01QVCB9LCAuLi5vcGVuYWlNZXNzYWdlc10sXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXG4gICAgICB0ZW1wZXJhdHVyZTogMC43LFxuICAgICAgcmVzcG9uc2VfZm9ybWF0OiB7IHR5cGU6IFwianNvbl9vYmplY3RcIiB9LFxuICAgIH0pO1xuXG4gICAgLy9KU09OX09CSkVDVFxuICAgIGNvbnN0IGFzc2lzdGFudE1lc3NhZ2UgPSByZXNwb25zZS5jaG9pY2VzWzBdLm1lc3NhZ2UuY29udGVudDtcblxuICAgIHJldHVybiB7XG4gICAgICBjb250ZW50OiBhc3Npc3RhbnRNZXNzYWdlLCAvL3JldHVybiBhIEpTT05fT0JKRUNUIG9mIHN1Z2dlc3RlZCBwcm9kdWN0c1xuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkNoYXQgQVBJIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiK1VBbUhzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:5c1ef6 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"00ac36e7027b6aca434bef1e49f0c686c3e40b8882":"getSerializedProducts"},"dev/cs160project/food-delivery-system-cs160/app/(user)/home/actions.ts",""] */ __turbopack_context__.s([
    "getSerializedProducts",
    ()=>getSerializedProducts
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getSerializedProducts = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("00ac36e7027b6aca434bef1e49f0c686c3e40b8882", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getSerializedProducts"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBQcm9kdWN0LCBQcm9kdWN0U3RhdHVzIH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2Uvc2VydmVyXCI7XG5pbXBvcnQgeyBnZXRDYXJ0SXRlbXMgfSBmcm9tIFwiLi4vY2hlY2tvdXQvYWN0aW9uc1wiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xuaW1wb3J0IHsgT3BlbkFJIH0gZnJvbSBcIm9wZW5haVwiO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuICBsZXQgcGVyc29uYWxfdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgIHdoZXJlOiB7IGF1dGhJZDogdXNlcj8uaWQgfSxcbiAgfSk7XG4gIGlmICghcGVyc29uYWxfdXNlcj8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZCBvciB1c2VyIElEIGlzIHVuZGVmaW5lZFwiKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZVByb2R1Y3RzKCk6IFByb21pc2U8UHJvZHVjdFtdPiB7XG4gIHJldHVybiBhd2FpdCBwcmlzbWEucHJvZHVjdC5maW5kTWFueSh7XG4gICAgd2hlcmU6IHsgc3RhdHVzOiBQcm9kdWN0U3RhdHVzLkFDVElWRSB9LFxuICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpYWxpemVkUHJvZHVjdHMoKTogUHJvbWlzZTxTZXJpYWxpemVkUHJvZHVjdFtdPiB7XG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgcHJpc21hLnByb2R1Y3QuZmluZE1hbnkoe1xuICAgIHdoZXJlOiB7IHN0YXR1czogUHJvZHVjdFN0YXR1cy5BQ1RJVkUgfSxcbiAgfSk7XG5cbiAgcmV0dXJuIHByb2R1Y3RzLm1hcCgocCkgPT4gKHtcbiAgICAuLi5wLFxuICAgIHByaWNlUGVyVW5pdDogcC5wcmljZVBlclVuaXQudG9OdW1iZXIoKSxcbiAgICB3ZWlnaHRQZXJVbml0OiBwLndlaWdodFBlclVuaXQudG9OdW1iZXIoKSxcbiAgfSkpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q2FydElkKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGxldCB1c2VySWQgPSBhd2FpdCBnZXRVc2VySWQoKTtcbiAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgaWYgKGNhcnQgPT0gbnVsbCkge1xuICAgIHJldHVybiAtMTsgLy8gc2hvdWxkIG5ldmVyIGhhcHBlbiBkdWUgdG8gZGF0YWJhc2UgY29uc3RyYWludFxuICB9IGVsc2Uge1xuICAgIHJldHVybiBjYXJ0LmlkO1xuICB9XG59XG5leHBvcnQgdHlwZSBBZGRUb0NhcnRTdGF0ZSA9IHtcbiAgc3VjY2Vzcz86IGJvb2xlYW47XG4gIGVycm9yPzogc3RyaW5nO1xuICBkYXRhPzogYW55O1xufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0NhcnRBY3Rpb24oXG4gIF9wcmV2U3RhdGU6IEFkZFRvQ2FydFN0YXRlLFxuICBmb3JtRGF0YTogRm9ybURhdGFcbik6IFByb21pc2U8QWRkVG9DYXJ0U3RhdGU+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjYXJ0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJjYXJ0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJwcm9kdWN0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBxdWFudGl0eSA9IHBhcnNlSW50KGZvcm1EYXRhLmdldChcInF1YW50aXR5XCIpIGFzIHN0cmluZyk7XG4gICAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICAgIGNvbnNvbGUubG9nKGNhcnRJZCwgdXNlcklkKTtcbiAgICBjb25zdCBhZGRlZEl0ZW0gPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0udXBzZXJ0KHtcbiAgICAgIHdoZXJlOiB7XG4gICAgICAgIGNhcnRJZF9wcm9kdWN0SWQ6IHtcbiAgICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IHtcbiAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxuICAgICAgfSxcbiAgICAgIGNyZWF0ZToge1xuICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0SWQsXG4gICAgICAgIHF1YW50aXR5OiBxdWFudGl0eSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV2YWxpZGF0ZVBhdGgoXCIvaG9tZVwiKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBhZGRlZEl0ZW0gfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHRvIGNhcnQ6XCIsIGVycm9yKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRmFpbGVkIHRvIGFkZCB0byBjYXJ0XCIgfTtcbiAgfVxufVxuXG4vLyAtLS0gU0VSVkVSIEFDVElPTiAtLS1cbmV4cG9ydCB0eXBlIFNlcmlhbGl6ZWRQcm9kdWN0ID0gT21pdDxcbiAgUHJvZHVjdCxcbiAgXCJwcmljZVBlclVuaXRcIiB8IFwid2VpZ2h0UGVyVW5pdFwiXG4+ICYge1xuICBwcmljZVBlclVuaXQ6IG51bWJlcjtcbiAgd2VpZ2h0UGVyVW5pdDogbnVtYmVyO1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBDYXJ0SXRlbSB7XG4gIGNhcnRJZDogbnVtYmVyO1xuICBpZDogbnVtYmVyO1xuICBwcm9kdWN0SWQ6IG51bWJlcjtcbiAgcXVhbnRpdHk6IG51bWJlcjtcbiAgcHJvZHVjdDogU2VyaWFsaXplZFByb2R1Y3Q7XG59XG5cbi8vIC0tLSBDSEFUQk9UIEFJIC0tLVxuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSSh7XG4gIGFwaUtleTogcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVksXG59KTtcblxudHlwZSBDaGF0TWVzc2FnZSA9IHtcbiAgcm9sZTogXCJ1c2VyXCIgfCBcImFzc2lzdGFudFwiO1xuICBjb250ZW50OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZENoYXRNZXNzYWdlKG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFtZXNzYWdlcyB8fCAhQXJyYXkuaXNBcnJheShtZXNzYWdlcykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbWVzc2FnZXMgZm9ybWF0XCIpO1xuICAgIH1cblxuICAgIGlmICghcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk9wZW5BSSBBUEkga2V5IG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgZ2V0QWN0aXZlUHJvZHVjdHMgZnVuY3Rpb25cbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IGdldEFjdGl2ZVByb2R1Y3RzKCk7XG5cbiAgICAvLyBGb3JtYXQgYWxsIHByb2R1Y3RzIGluIERCIGZvciB0aGUgQUkgY29udGV4dCB3aXRoIElELCBuYW1lLCBhbmQgaW5ncmVkaWVudHNcbiAgICBjb25zdCBwcm9kdWN0c0NvbnRleHQgPVxuICAgICAgcHJvZHVjdHNcbiAgICAgICAgPy5tYXAoXG4gICAgICAgICAgKHApID0+IGBJRDogJHtwLmlkfSwgTmFtZTogJHtwLm5hbWV9LCBJbmdyZWRpZW50czogJHtwLmRlc2NyaXB0aW9ufWBcbiAgICAgICAgKVxuICAgICAgICAuam9pbihcIlxcblwiKSB8fCBcIk5vIHByb2R1Y3RzIGF2YWlsYWJsZVwiO1xuXG4gICAgLy8gSW4gc2VuZENoYXRNZXNzYWdlIGZ1bmN0aW9uLCB1cGRhdGUgdGhlIFNZU1RFTV9QUk9NUFQ6XG4gICAgY29uc3QgU1lTVEVNX1BST01QVCA9IGBZb3UgYXJlIGFuIEFJIGFzc2lzdGFudCBmb3IgYSBmb29kIGRlbGl2ZXJ5IHNlcnZpY2UgdGhhdCBoZWxwcyB1c2VycyBmaW5kIGluZ3JlZGllbnRzLlxuXG5BdmFpbGFibGUgUHJvZHVjdHM6XG4ke3Byb2R1Y3RzQ29udGV4dH1cblxuV2hlbiBhIHVzZXIgYXNrcyBhYm91dCBpbmdyZWRpZW50cyBmb3IgYSByZWNpcGUgb3IgbWVhbCwgYW5hbHl6ZSB0aGVpciByZXF1ZXN0IGFuZCByZXNwb25kIHdpdGggYSBKU09OIG9iamVjdCBjb250YWluaW5nIGEgXCJwcm9kdWN0c1wiIGFycmF5LiBFYWNoIHByb2R1Y3Qgc2hvdWxkIGluY2x1ZGU6XG4tIHByb2R1Y3RJRDogdGhlIHByb2R1Y3QgSUQgbnVtYmVyXG4tIHByb2R1Y3ROYW1lOiB0aGUgcHJvZHVjdCBuYW1lXG4tIHF1YW50aXR5OiBlc3RpbWF0ZWQgcXVhbnRpdHkgbmVlZGVkIChhcyBhIG51bWJlcilcblxuRXhhbXBsZSByZXNwb25zZSBmb3JtYXQ6XG57XG4gIFwicHJvZHVjdHNcIjogW1xuICAgIHtcInByb2R1Y3RJRFwiOiAxLCBcInByb2R1Y3ROYW1lXCI6IFwiVG9tYXRvZXNcIiwgXCJxdWFudGl0eVwiOiAzfSxcbiAgICB7XCJwcm9kdWN0SURcIjogNSwgXCJwcm9kdWN0TmFtZVwiOiBcIk9uaW9uc1wiLCBcInF1YW50aXR5XCI6IDJ9XG4gIF1cbn1cblxuSU1QT1JUQU5UOlxuLSBSZXNwb25kIE9OTFkgd2l0aCB0aGUgSlNPTiBvYmplY3QgY29udGFpbmluZyBhIFwicHJvZHVjdHNcIiBhcnJheSwgbm8gYWRkaXRpb25hbCB0ZXh0XG4tIEJhc2UgeW91ciByZXNwb25zZSBvbiB0aGUgYXZhaWxhYmxlIHByb2R1Y3RzIGxpc3RlZCBhYm92ZVxuLSBJZiB0aGUgdXNlciBhc2tzIGEgbm9uLWluZ3JlZGllbnQgcXVlc3Rpb24sIHJlc3BvbmQgd2l0aDoge1wicHJvZHVjdHNcIjogW119XG4tIEVzdGltYXRlIHJlYXNvbmFibGUgcXVhbnRpdGllcyBiYXNlZCBvbiB0aGUgcmVjaXBlIG9yIHJlcXVlc3RgO1xuXG4gICAgY29uc3Qgb3BlbmFpTWVzc2FnZXMgPSBtZXNzYWdlcy5tYXAoKG1zZykgPT4gKHtcbiAgICAgIHJvbGU6IG1zZy5yb2xlIGFzIFwidXNlclwiIHwgXCJhc3Npc3RhbnRcIixcbiAgICAgIGNvbnRlbnQ6IG1zZy5jb250ZW50LFxuICAgIH0pKTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcbiAgICAgIG1vZGVsOiBcImdwdC00by1taW5pXCIsXG4gICAgICBtZXNzYWdlczogW3sgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogU1lTVEVNX1BST01QVCB9LCAuLi5vcGVuYWlNZXNzYWdlc10sXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXG4gICAgICB0ZW1wZXJhdHVyZTogMC43LFxuICAgICAgcmVzcG9uc2VfZm9ybWF0OiB7IHR5cGU6IFwianNvbl9vYmplY3RcIiB9LFxuICAgIH0pO1xuXG4gICAgLy9KU09OX09CSkVDVFxuICAgIGNvbnN0IGFzc2lzdGFudE1lc3NhZ2UgPSByZXNwb25zZS5jaG9pY2VzWzBdLm1lc3NhZ2UuY29udGVudDtcblxuICAgIHJldHVybiB7XG4gICAgICBjb250ZW50OiBhc3Npc3RhbnRNZXNzYWdlLCAvL3JldHVybiBhIEpTT05fT0JKRUNUIG9mIHN1Z2dlc3RlZCBwcm9kdWN0c1xuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkNoYXQgQVBJIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoicVZBNEJzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:cf24a0 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"003db6e1542f76126ed1410054724d1cb2b47fd4df":"getCartId"},"dev/cs160project/food-delivery-system-cs160/app/(user)/home/actions.ts",""] */ __turbopack_context__.s([
    "getCartId",
    ()=>getCartId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getCartId = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("003db6e1542f76126ed1410054724d1cb2b47fd4df", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getCartId"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBQcm9kdWN0LCBQcm9kdWN0U3RhdHVzIH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyBjcmVhdGVDbGllbnQgfSBmcm9tIFwiQC9saWIvc3VwYWJhc2Uvc2VydmVyXCI7XG5pbXBvcnQgeyBnZXRDYXJ0SXRlbXMgfSBmcm9tIFwiLi4vY2hlY2tvdXQvYWN0aW9uc1wiO1xuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xuaW1wb3J0IHsgT3BlbkFJIH0gZnJvbSBcIm9wZW5haVwiO1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7IHVzZXIgfSxcbiAgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguZ2V0VXNlcigpO1xuICBsZXQgcGVyc29uYWxfdXNlciA9IGF3YWl0IHByaXNtYS51c2VyLmZpbmRVbmlxdWUoe1xuICAgIHdoZXJlOiB7IGF1dGhJZDogdXNlcj8uaWQgfSxcbiAgfSk7XG4gIGlmICghcGVyc29uYWxfdXNlcj8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZCBvciB1c2VyIElEIGlzIHVuZGVmaW5lZFwiKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZVByb2R1Y3RzKCk6IFByb21pc2U8UHJvZHVjdFtdPiB7XG4gIHJldHVybiBhd2FpdCBwcmlzbWEucHJvZHVjdC5maW5kTWFueSh7XG4gICAgd2hlcmU6IHsgc3RhdHVzOiBQcm9kdWN0U3RhdHVzLkFDVElWRSB9LFxuICB9KTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJpYWxpemVkUHJvZHVjdHMoKTogUHJvbWlzZTxTZXJpYWxpemVkUHJvZHVjdFtdPiB7XG4gIGNvbnN0IHByb2R1Y3RzID0gYXdhaXQgcHJpc21hLnByb2R1Y3QuZmluZE1hbnkoe1xuICAgIHdoZXJlOiB7IHN0YXR1czogUHJvZHVjdFN0YXR1cy5BQ1RJVkUgfSxcbiAgfSk7XG5cbiAgcmV0dXJuIHByb2R1Y3RzLm1hcCgocCkgPT4gKHtcbiAgICAuLi5wLFxuICAgIHByaWNlUGVyVW5pdDogcC5wcmljZVBlclVuaXQudG9OdW1iZXIoKSxcbiAgICB3ZWlnaHRQZXJVbml0OiBwLndlaWdodFBlclVuaXQudG9OdW1iZXIoKSxcbiAgfSkpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0Q2FydElkKCk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGxldCB1c2VySWQgPSBhd2FpdCBnZXRVc2VySWQoKTtcbiAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgaWYgKGNhcnQgPT0gbnVsbCkge1xuICAgIHJldHVybiAtMTsgLy8gc2hvdWxkIG5ldmVyIGhhcHBlbiBkdWUgdG8gZGF0YWJhc2UgY29uc3RyYWludFxuICB9IGVsc2Uge1xuICAgIHJldHVybiBjYXJ0LmlkO1xuICB9XG59XG5leHBvcnQgdHlwZSBBZGRUb0NhcnRTdGF0ZSA9IHtcbiAgc3VjY2Vzcz86IGJvb2xlYW47XG4gIGVycm9yPzogc3RyaW5nO1xuICBkYXRhPzogYW55O1xufTtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRUb0NhcnRBY3Rpb24oXG4gIF9wcmV2U3RhdGU6IEFkZFRvQ2FydFN0YXRlLFxuICBmb3JtRGF0YTogRm9ybURhdGFcbik6IFByb21pc2U8QWRkVG9DYXJ0U3RhdGU+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCBjYXJ0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJjYXJ0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBwYXJzZUludChmb3JtRGF0YS5nZXQoXCJwcm9kdWN0SWRcIikgYXMgc3RyaW5nKTtcbiAgICBjb25zdCBxdWFudGl0eSA9IHBhcnNlSW50KGZvcm1EYXRhLmdldChcInF1YW50aXR5XCIpIGFzIHN0cmluZyk7XG4gICAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICAgIGNvbnNvbGUubG9nKGNhcnRJZCwgdXNlcklkKTtcbiAgICBjb25zdCBhZGRlZEl0ZW0gPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0udXBzZXJ0KHtcbiAgICAgIHdoZXJlOiB7XG4gICAgICAgIGNhcnRJZF9wcm9kdWN0SWQ6IHtcbiAgICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICB1cGRhdGU6IHtcbiAgICAgICAgcXVhbnRpdHk6IHF1YW50aXR5LFxuICAgICAgfSxcbiAgICAgIGNyZWF0ZToge1xuICAgICAgICBjYXJ0SWQ6IGNhcnRJZCxcbiAgICAgICAgcHJvZHVjdElkOiBwcm9kdWN0SWQsXG4gICAgICAgIHF1YW50aXR5OiBxdWFudGl0eSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgcmV2YWxpZGF0ZVBhdGgoXCIvaG9tZVwiKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCBkYXRhOiBhZGRlZEl0ZW0gfTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKFwiRXJyb3IgYWRkaW5nIHRvIGNhcnQ6XCIsIGVycm9yKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiRmFpbGVkIHRvIGFkZCB0byBjYXJ0XCIgfTtcbiAgfVxufVxuXG4vLyAtLS0gU0VSVkVSIEFDVElPTiAtLS1cbmV4cG9ydCB0eXBlIFNlcmlhbGl6ZWRQcm9kdWN0ID0gT21pdDxcbiAgUHJvZHVjdCxcbiAgXCJwcmljZVBlclVuaXRcIiB8IFwid2VpZ2h0UGVyVW5pdFwiXG4+ICYge1xuICBwcmljZVBlclVuaXQ6IG51bWJlcjtcbiAgd2VpZ2h0UGVyVW5pdDogbnVtYmVyO1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBDYXJ0SXRlbSB7XG4gIGNhcnRJZDogbnVtYmVyO1xuICBpZDogbnVtYmVyO1xuICBwcm9kdWN0SWQ6IG51bWJlcjtcbiAgcXVhbnRpdHk6IG51bWJlcjtcbiAgcHJvZHVjdDogU2VyaWFsaXplZFByb2R1Y3Q7XG59XG5cbi8vIC0tLSBDSEFUQk9UIEFJIC0tLVxuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSSh7XG4gIGFwaUtleTogcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVksXG59KTtcblxudHlwZSBDaGF0TWVzc2FnZSA9IHtcbiAgcm9sZTogXCJ1c2VyXCIgfCBcImFzc2lzdGFudFwiO1xuICBjb250ZW50OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZENoYXRNZXNzYWdlKG1lc3NhZ2VzOiBDaGF0TWVzc2FnZVtdKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFtZXNzYWdlcyB8fCAhQXJyYXkuaXNBcnJheShtZXNzYWdlcykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgbWVzc2FnZXMgZm9ybWF0XCIpO1xuICAgIH1cblxuICAgIGlmICghcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk9wZW5BSSBBUEkga2V5IG5vdCBjb25maWd1cmVkXCIpO1xuICAgIH1cblxuICAgIC8vIFVzZSB0aGUgZXhpc3RpbmcgZ2V0QWN0aXZlUHJvZHVjdHMgZnVuY3Rpb25cbiAgICBjb25zdCBwcm9kdWN0cyA9IGF3YWl0IGdldEFjdGl2ZVByb2R1Y3RzKCk7XG5cbiAgICAvLyBGb3JtYXQgYWxsIHByb2R1Y3RzIGluIERCIGZvciB0aGUgQUkgY29udGV4dCB3aXRoIElELCBuYW1lLCBhbmQgaW5ncmVkaWVudHNcbiAgICBjb25zdCBwcm9kdWN0c0NvbnRleHQgPVxuICAgICAgcHJvZHVjdHNcbiAgICAgICAgPy5tYXAoXG4gICAgICAgICAgKHApID0+IGBJRDogJHtwLmlkfSwgTmFtZTogJHtwLm5hbWV9LCBJbmdyZWRpZW50czogJHtwLmRlc2NyaXB0aW9ufWBcbiAgICAgICAgKVxuICAgICAgICAuam9pbihcIlxcblwiKSB8fCBcIk5vIHByb2R1Y3RzIGF2YWlsYWJsZVwiO1xuXG4gICAgLy8gSW4gc2VuZENoYXRNZXNzYWdlIGZ1bmN0aW9uLCB1cGRhdGUgdGhlIFNZU1RFTV9QUk9NUFQ6XG4gICAgY29uc3QgU1lTVEVNX1BST01QVCA9IGBZb3UgYXJlIGFuIEFJIGFzc2lzdGFudCBmb3IgYSBmb29kIGRlbGl2ZXJ5IHNlcnZpY2UgdGhhdCBoZWxwcyB1c2VycyBmaW5kIGluZ3JlZGllbnRzLlxuXG5BdmFpbGFibGUgUHJvZHVjdHM6XG4ke3Byb2R1Y3RzQ29udGV4dH1cblxuV2hlbiBhIHVzZXIgYXNrcyBhYm91dCBpbmdyZWRpZW50cyBmb3IgYSByZWNpcGUgb3IgbWVhbCwgYW5hbHl6ZSB0aGVpciByZXF1ZXN0IGFuZCByZXNwb25kIHdpdGggYSBKU09OIG9iamVjdCBjb250YWluaW5nIGEgXCJwcm9kdWN0c1wiIGFycmF5LiBFYWNoIHByb2R1Y3Qgc2hvdWxkIGluY2x1ZGU6XG4tIHByb2R1Y3RJRDogdGhlIHByb2R1Y3QgSUQgbnVtYmVyXG4tIHByb2R1Y3ROYW1lOiB0aGUgcHJvZHVjdCBuYW1lXG4tIHF1YW50aXR5OiBlc3RpbWF0ZWQgcXVhbnRpdHkgbmVlZGVkIChhcyBhIG51bWJlcilcblxuRXhhbXBsZSByZXNwb25zZSBmb3JtYXQ6XG57XG4gIFwicHJvZHVjdHNcIjogW1xuICAgIHtcInByb2R1Y3RJRFwiOiAxLCBcInByb2R1Y3ROYW1lXCI6IFwiVG9tYXRvZXNcIiwgXCJxdWFudGl0eVwiOiAzfSxcbiAgICB7XCJwcm9kdWN0SURcIjogNSwgXCJwcm9kdWN0TmFtZVwiOiBcIk9uaW9uc1wiLCBcInF1YW50aXR5XCI6IDJ9XG4gIF1cbn1cblxuSU1QT1JUQU5UOlxuLSBSZXNwb25kIE9OTFkgd2l0aCB0aGUgSlNPTiBvYmplY3QgY29udGFpbmluZyBhIFwicHJvZHVjdHNcIiBhcnJheSwgbm8gYWRkaXRpb25hbCB0ZXh0XG4tIEJhc2UgeW91ciByZXNwb25zZSBvbiB0aGUgYXZhaWxhYmxlIHByb2R1Y3RzIGxpc3RlZCBhYm92ZVxuLSBJZiB0aGUgdXNlciBhc2tzIGEgbm9uLWluZ3JlZGllbnQgcXVlc3Rpb24sIHJlc3BvbmQgd2l0aDoge1wicHJvZHVjdHNcIjogW119XG4tIEVzdGltYXRlIHJlYXNvbmFibGUgcXVhbnRpdGllcyBiYXNlZCBvbiB0aGUgcmVjaXBlIG9yIHJlcXVlc3RgO1xuXG4gICAgY29uc3Qgb3BlbmFpTWVzc2FnZXMgPSBtZXNzYWdlcy5tYXAoKG1zZykgPT4gKHtcbiAgICAgIHJvbGU6IG1zZy5yb2xlIGFzIFwidXNlclwiIHwgXCJhc3Npc3RhbnRcIixcbiAgICAgIGNvbnRlbnQ6IG1zZy5jb250ZW50LFxuICAgIH0pKTtcblxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgb3BlbmFpLmNoYXQuY29tcGxldGlvbnMuY3JlYXRlKHtcbiAgICAgIG1vZGVsOiBcImdwdC00by1taW5pXCIsXG4gICAgICBtZXNzYWdlczogW3sgcm9sZTogXCJzeXN0ZW1cIiwgY29udGVudDogU1lTVEVNX1BST01QVCB9LCAuLi5vcGVuYWlNZXNzYWdlc10sXG4gICAgICBtYXhfdG9rZW5zOiAzMDAsXG4gICAgICB0ZW1wZXJhdHVyZTogMC43LFxuICAgICAgcmVzcG9uc2VfZm9ybWF0OiB7IHR5cGU6IFwianNvbl9vYmplY3RcIiB9LFxuICAgIH0pO1xuXG4gICAgLy9KU09OX09CSkVDVFxuICAgIGNvbnN0IGFzc2lzdGFudE1lc3NhZ2UgPSByZXNwb25zZS5jaG9pY2VzWzBdLm1lc3NhZ2UuY29udGVudDtcblxuICAgIHJldHVybiB7XG4gICAgICBjb250ZW50OiBhc3Npc3RhbnRNZXNzYWdlLCAvL3JldHVybiBhIEpTT05fT0JKRUNUIG9mIHN1Z2dlc3RlZCBwcm9kdWN0c1xuICAgIH07XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkNoYXQgQVBJIGVycm9yOlwiLCBlcnJvcik7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoieVVBd0NzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/data:ca19b6 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"000aec9d0ee61ba71cce82e768cf1bd8d3b6725b5a":"getCartItems"},"dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/actions.ts",""] */ __turbopack_context__.s([
    "getCartItems",
    ()=>getCartItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var getCartItems = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("000aec9d0ee61ba71cce82e768cf1bd8d3b6725b5a", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "getCartItems"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XG5cbmltcG9ydCBwcmlzbWEgZnJvbSAnQC9saWIvcHJpc21hJztcbmltcG9ydCB7Y3JlYXRlQ2xpZW50fSBmcm9tICdAL2xpYi9zdXBhYmFzZS9zZXJ2ZXInO1xuaW1wb3J0IHtEZWxpdmVyeUFkZHJlc3MsIFByaXNtYSwgUHJvZHVjdCwgT3JkZXJ9IGZyb20gJ0BwcmlzbWEvY2xpZW50JztcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XG5cbi8vIERlZmluZSBxdWVyeSB0eXBlIGZvciBDYXJ0IHdpdGggQ2FydGl0ZW0gYW5kIHByb2R1Y3RzXG5jb25zdCBjYXJ0V2l0aEl0ZW1zQW5kUHJvZHVjdCA9IFByaXNtYS52YWxpZGF0b3I8UHJpc21hLkNhcnREZWZhdWx0QXJncz4oKSh7XG4gIGluY2x1ZGU6IHtcbiAgICBjYXJ0SXRlbXM6IHtcbiAgICAgIGluY2x1ZGU6IHtcbiAgICAgICAgcHJvZHVjdDogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn0pO1xuXG4vLyBEZWZpbmUgcXVlcnkgcmV0dXJuIHR5cGUgZm9yIHR5cGUgY2hlY2tpbmcgKFRTKVxuZXhwb3J0IHR5cGUgQ2FydFdpdGhJdGVtc0FuZFByb2R1Y3QgPVxuICAgIFByaXNtYS5DYXJ0R2V0UGF5bG9hZDx0eXBlb2YgY2FydFdpdGhJdGVtc0FuZFByb2R1Y3Q+O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7dXNlcn0sXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcbiAgbGV0IHBlcnNvbmFsX3VzZXIgPSBhd2FpdCBwcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICB3aGVyZToge2F1dGhJZDogdXNlcj8uaWR9LFxuICB9KTtcbiAgaWYgKCFwZXJzb25hbF91c2VyPy5pZCkge1xuICAgIHRocm93IG5ldyBFcnJvcignVXNlciBub3QgZm91bmQgb3IgdXNlciBJRCBpcyB1bmRlZmluZWQnKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDYXJ0SXRlbXMoKSB7XG4gIC8vIGZpcnN0IGdldCB1c2VySWRcbiAgLy8gZ2V0IGNhcnQgaWQgZnJvbSB1c2VySWQgZnJvbSB0aGUgY2FydCB0YWJsZVxuICAvLyByZXR1cm4gYWxsIGNhcnRJdGVtcyB3aXRoIGEgY2VydGFpbiBjYXJ0SURcbiAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICBsZXQgY2FydElkID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7d2hlcmU6IHt1c2VySWQ6IHVzZXJJZH19KTtcbiAgaWYgKGNhcnRJZCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGxldCBjYXJ0ID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgIH0sXG4gICAgLi4uY2FydFdpdGhJdGVtc0FuZFByb2R1Y3QsXG4gIH0pO1xuICBpZiAoIWNhcnQpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgbGV0IHRvUmV0dXJuID0gY2FydD8uY2FydEl0ZW1zLm1hcChcbiAgICAgIChpdGVtKSA9PiB7cmV0dXJuICh7XG4gICAgICAgIC4uLml0ZW0sXG4gICAgICAgIHByb2R1Y3Q6IHtcbiAgICAgICAgICAuLi5pdGVtLnByb2R1Y3QsXG4gICAgICAgICAgcHJpY2VQZXJVbml0OiBpdGVtLnByb2R1Y3QucHJpY2VQZXJVbml0LnRvTnVtYmVyKCksXG4gICAgICAgICAgd2VpZ2h0UGVyVW5pdDogaXRlbS5wcm9kdWN0LndlaWdodFBlclVuaXQudG9OdW1iZXIoKVxuICAgICAgICB9XG4gICAgICB9KX0pXG5cbiAgcmV0dXJuIHRvUmV0dXJuO1xufVxuXG5leHBvcnQgdHlwZSBDaGVja291dFN0YXRlID0ge1xuICBvaz86IGJvb2xlYW47XG4gIGZvcm1FcnJvcj86IHN0cmluZztcbiAgZmllbGRFcnJvcnM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWRkcmVzc2VzKCk6IFByb21pc2U8RGVsaXZlcnlBZGRyZXNzW10+IHtcbiAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICBsZXQgYWRkcmVzc2VzID0gYXdhaXQgcHJpc21hLmRlbGl2ZXJ5QWRkcmVzcy5maW5kTWFueSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgIH1cbiAgfVxuICApXG4gIHJldHVybiBhZGRyZXNzZXM7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjaGVja291dEFjdGlvbihcbiAgICBwcmV2U3RhdGU6IENoZWNrb3V0U3RhdGUsIGZvcm1EYXRhOiBGb3JtRGF0YSk6IFByb21pc2U8Q2hlY2tvdXRTdGF0ZT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXNKc29uID0gZm9ybURhdGEuZ2V0KCdzZWxlY3RlZEl0ZW1zJykgYXMgc3RyaW5nO1xuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSBKU09OLnBhcnNlKHNlbGVjdGVkSXRlbXNKc29uKTtcbiAgICBjb25zdCBzZWxlY3RlZEFkZHJlc3NJZCA9IGZvcm1EYXRhLmdldCgnc2VsZWN0ZWRBZGRyZXNzSWQnKSBhcyBzdHJpbmc7XG5cbiAgICBsZXQgdXNlcklkID0gYXdhaXQgZ2V0VXNlcklkKCk7XG4gICAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgICBsZXQgYWRkcmVzc2VzID0gYXdhaXQgZ2V0QWRkcmVzc2VzKCk7XG4gICAgaWYgKGFkZHJlc3Nlcy5sZW5ndGggPD0gMCkge1xuICAgICAgcmV0dXJuIHsgZm9ybUVycm9yOiBcIllvdSBkbyBub3QgaGF2ZSBhbiBhZGRyZXNzIHNldFwiIH07XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHNlbGVjdGVkQWRkcmVzcyA9IGFkZHJlc3Nlcy5maW5kKGFkZHIgPT4gYWRkci5pZCA9PT0gcGFyc2VJbnQoc2VsZWN0ZWRBZGRyZXNzSWQpKTtcbiAgICBpZiAoIXNlbGVjdGVkQWRkcmVzcykge1xuICAgICAgcmV0dXJuIHsgZm9ybUVycm9yOiBcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCBkZWxpdmVyeSBhZGRyZXNzXCIgfTtcbiAgICB9XG4gICAgXG4gICAgY29uc3Qgb3JkZXIgPSBhd2FpdCBwcmlzbWEub3JkZXIuY3JlYXRlKHtcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIHN0YXR1czogJ1BFTkRJTkcnLFxuICAgICAgICB0b0FkZHJlc3M6IHNlbGVjdGVkQWRkcmVzcy5hZGRyZXNzLCBcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGNvbnN0IHByb2R1Y3RJZHMgPSBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbTogYW55KSA9PiBpdGVtLnByb2R1Y3RJZCk7XG5cbiAgICBjb25zdCBvcmRlckl0ZW1zID0gYXdhaXQgcHJpc21hLm9yZGVySXRlbS5jcmVhdGVNYW55KHtcbiAgICAgIGRhdGE6IHNlbGVjdGVkSXRlbXMubWFwKChpdGVtOiBhbnkpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVySWQ6IG9yZGVyLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IGl0ZW0ucHJvZHVjdElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpY2VQZXJVbml0OiBpdGVtLnByaWNlUGVyVW5pdCwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlaWdodFBlclVuaXQ6IGl0ZW0ud2VpZ2h0UGVyVW5pdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpLFxuICAgIH0pO1xuICAgIC8vIGNyZWF0ZSBvcmRlciBpdGVtcyB3aXRoIHRoZSBjb3JyZWN0IG9yZGVyIElEXG4gICAgLy8gcmVtb3ZlIHNlbGVjdGVkSXRlbXMgZnJvbSByZWFsQ2FydCBhbmQgdXBkYXRlIGNhcnRcbiAgICBjb25zdCByZW1vdmVfaXRlbXMgPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0uZGVsZXRlTWFueSh7XG4gICAgICB3aGVyZToge2NhcnRJZDogY2FydD8uaWQsIHByb2R1Y3RJZDoge2luIDogcHJvZHVjdElkc319LFxuICAgIH0pO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5sb2coJ3NvbWUgZXJyb3I6JywgZXJyb3IpO1xuICAgIHJldHVybiB7Zm9ybUVycm9yOiAnQ2hlY2tvdXQgZmFpbGVkLCBzb21lIHByb2JsZW0gb2NjdXJlZCd9O1xuICB9XG4gIHJldmFsaWRhdGVQYXRoKCcvaG9tZScpO1xuICByZWRpcmVjdCgnL2hvbWUnKVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJnVkFvQ3NCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductSelectionModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$ca19b6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/data:ca19b6 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ProductSelectionModal(param) {
    let { isOpen, onClose, suggestedProducts, allProducts, cartId, cartItems: initialCartItems, onCartUpdate } = param;
    _s();
    const [cartItems, setCartItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCartItems);
    // Update local cart items when prop changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductSelectionModal.useEffect": ()=>{
            setCartItems(initialCartItems);
        }
    }["ProductSelectionModal.useEffect"], [
        initialCartItems
    ]);
    //When cart updates, we handle such change
    const handleCartChange = async ()=>{
        const cartItems = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$ca19b6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getCartItems"])();
        setCartItems(cartItems);
        onCartUpdate(cartItems);
    };
    // Match suggested products with full product data from DB and our existing cart information
    const matchedProducts = suggestedProducts.map((sp)=>{
        const product = allProducts.find((p)=>p.id === sp.productID);
        return product ? {
            product,
            suggestedQuantity: sp.quantity
        } : null;
    }).filter(Boolean);
    if (!isOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-lg shadow-xl max-w-6xl w-full mx-4 max-h-[90vh] flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between p-6 border-b",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold",
                            children: [
                                "Suggested Ingredients (",
                                suggestedProducts.length,
                                " items)"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                            lineNumber: 66,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: onClose,
                            className: "p-2 hover:bg-gray-100 rounded-full transition-colors",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                className: "w-6 h-6"
                            }, void 0, false, {
                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                                lineNumber: 71,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-y-auto p-6",
                    children: matchedProducts.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-center text-gray-500 py-8",
                        children: "No products found matching your request."
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                        lineNumber: 78,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
                        children: matchedProducts.map((param)=>{
                            let { product, suggestedQuantity } = param;
                            const cartItem = cartItems.find((item)=>item.productId === product.id);
                            const isInCart = !!cartItem;
                            const currentQuantity = (cartItem === null || cartItem === void 0 ? void 0 : cartItem.quantity) || suggestedQuantity;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ProductCard"], {
                                product: product,
                                isInCart: isInCart,
                                quantity: currentQuantity,
                                cartId: cartId,
                                onCartChange: handleCartChange
                            }, product.id, false, {
                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                                lineNumber: 89,
                                columnNumber: 19
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                        lineNumber: 82,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 border-t bg-gray-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            onClick: onClose,
                            children: "Close"
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                            lineNumber: 106,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                        lineNumber: 105,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
                    lineNumber: 104,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
            lineNumber: 63,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx",
        lineNumber: 62,
        columnNumber: 5
    }, this);
}
_s(ProductSelectionModal, "82lkBXncw2eJ+Yrd2qk5eCKZldw=");
_c = ProductSelectionModal;
var _c;
__turbopack_context__.k.register(_c, "ProductSelectionModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ChatWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/send.js [app-client] (ecmascript) <export default as Send>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/scroll-area.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$499dce__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:499dce [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$5c1ef6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:5c1ef6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$cf24a0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/data:cf24a0 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$ca19b6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/data:ca19b6 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$suggest$2d$modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/product-suggest-modal.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function ChatWidget() {
    var _messages_;
    _s();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: crypto.randomUUID(),
            role: "assistant",
            content: "Hi! I'm your site assistant. Ask me anything about this page."
        }
    ]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [modalOpen, setModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false); //Modal Pop Up state
    const [suggestedProducts, setSuggestedProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [allProducts, setAllProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cartItems, setCartItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [cartId, setCartId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const listEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    //SCROLLING IN CHAT
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatWidget.useEffect": ()=>{
            var _listEndRef_current;
            (_listEndRef_current = listEndRef.current) === null || _listEndRef_current === void 0 ? void 0 : _listEndRef_current.scrollIntoView({
                behavior: "smooth"
            });
        }
    }["ChatWidget.useEffect"], [
        messages,
        open
    ]);
    //OPEN CHATWIDGET
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatWidget.useEffect": ()=>{
            if (open) {
                setTimeout({
                    "ChatWidget.useEffect": ()=>{
                        var _inputRef_current;
                        return (_inputRef_current = inputRef.current) === null || _inputRef_current === void 0 ? void 0 : _inputRef_current.focus();
                    }
                }["ChatWidget.useEffect"], 50);
            }
        }
    }["ChatWidget.useEffect"], [
        open
    ]);
    //TAKES JSON_OBJ from openAI and parses it. Makes it an obj in which e.g. (obj.productName would return "Spinach");
    const parseProductSuggestions = (content)=>{
        try {
            const parsed = JSON.parse(content);
            // Handle both array format and object with products array
            if (Array.isArray(parsed)) {
                return parsed;
            } else if (parsed.products && Array.isArray(parsed.products)) {
                return parsed.products;
            }
            return null;
        } catch (e) {
            return null;
        }
    };
    //USERS MESSAGE SENDS TO OPENAI
    const sendToOpenAI = async (userText, currentMessages)=>{
        // Check if data is loaded before processing
        if (allProducts.length === 0 || cartId === -1) {
            try {
                const products = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$5c1ef6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getSerializedProducts"])();
                const id = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$cf24a0__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getCartId"])();
                const items = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$ca19b6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getCartItems"])();
                setAllProducts(products);
                setCartId(id);
                setCartItems(items);
            } catch (error) {
                console.error('Failed to reload data:', error);
            }
        }
        //AI message thinking
        const thinking = {
            id: crypto.randomUUID(),
            role: "assistant",
            content: "Thinking…"
        };
        setMessages((prev)=>[
                ...prev,
                thinking
            ]);
        //RESPONSE CALLS sendChatMESSAGE in actions.ts which return a JSON_OBJECT of suggested products
        try {
            const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$data$3a$499dce__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["sendChatMessage"])(currentMessages.map((m)=>({
                    role: m.role,
                    content: m.content
                })));
            const assistantMessage = response.content || "I couldn't generate a response. Please try again."; //JSON OBJECT
            //PARSE JSON_OBJECT to return an Typescript object
            const suggestions = parseProductSuggestions(assistantMessage);
            //IF THERE ARE SUGGESTED PRODUCTS
            if (suggestions && suggestions.length > 0) {
                // Refresh cart items before showing modal
                const cartItems = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$ca19b6__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["getCartItems"])();
                setCartItems(cartItems);
                // Show the modal with suggestions
                setSuggestedProducts(suggestions);
                setModalOpen(true);
                setMessages((prev)=>prev.map((m)=>m.id === thinking.id ? {
                            ...m,
                            content: "I found ".concat(suggestions.length, " ingredient").concat(suggestions.length > 1 ? 's' : '', " for you!")
                        } : m));
            } else {
                setMessages((prev)=>prev.map((m)=>m.id === thinking.id ? {
                            ...m,
                            content: "I couldn't generate a response from the provided information. Please try again."
                        } : m));
            }
        } catch (error) {
            console.error('Chat error:', error);
            setMessages((prev)=>prev.map((m)=>m.id === thinking.id ? {
                        ...m,
                        content: "Sorry, I encountered an error. Please try again later."
                    } : m));
        }
    };
    // --- TAKE USER INPUT AND SEND IT TO OPENAI --- 
    const onSend = ()=>{
        const text = input.trim();
        if (!text) return;
        //Text is userMsg, role user
        const userMsg = {
            id: crypto.randomUUID(),
            role: "user",
            content: text
        };
        setMessages((prev)=>[
                ...prev,
                userMsg
            ]);
        setInput("");
        //Send userMsg to OPENAI
        sendToOpenAI(text, [
            ...messages,
            userMsg
        ]);
    };
    // --- MESSAGE ENTER EVENT --- 
    const onKeyDown = (e)=>{
        if (e.key === "Enter") {
            e.preventDefault();
            onSend();
        }
    };
    // --- CART UPDATES WHEN MODAL USER ACTIONS OCCUR --- 
    const handleCartUpdate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ChatWidget.useCallback[handleCartUpdate]": (items)=>{
            setCartItems(items);
        }
    }["ChatWidget.useCallback[handleCartUpdate]"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed right-4 bottom-4 z-50",
                children: [
                    !open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        "aria-label": "Open chat",
                        onClick: ()=>setOpen(true),
                        className: "h-14 w-14 rounded-full shadow-lg flex items-center justify-center border border-white/70 bg-blue-600 text-white hover:bg-blue-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                            className: "h-6 w-6"
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                            lineNumber: 177,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                        lineNumber: 172,
                        columnNumber: 11
                    }, this),
                    open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
                        className: "w-[320px] sm:w-[360px] max-h-[70vh] shadow-2xl border-blue-100",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                                className: "p-3 pb-2 bg-blue-600 text-white rounded-t-xl",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                            className: "text-base font-semibold",
                                            children: "Chat"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                            lineNumber: 186,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            size: "icon",
                                            variant: "secondary",
                                            "aria-label": "Close chat",
                                            onClick: ()=>setOpen(false),
                                            className: "h-8 w-8 rounded-full bg-white/20 hover:bg-white/30 text-white border border-white/30",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                className: "h-4 w-4"
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                lineNumber: 194,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                            lineNumber: 187,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                    lineNumber: 185,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                lineNumber: 184,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                                className: "p-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col h-[52vh]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$scroll$2d$area$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ScrollArea"], {
                                            className: "flex-1 p-3 overflow-y-auto",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-3",
                                                children: [
                                                    messages.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex ".concat(m.role === "user" ? "justify-end" : "justify-start"),
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: m.role === "user" ? "max-w-[80%] rounded-2xl px-3 py-2 bg-blue-600 text-white shadow break-words" : "max-w-[80%] rounded-2xl px-3 py-2 bg-white text-blue-900 border border-blue-100 shadow break-words",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-sm leading-relaxed whitespace-pre-wrap break-words",
                                                                    children: m.content
                                                                }, void 0, false, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                                    lineNumber: 212,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                                lineNumber: 205,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, m.id, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                            lineNumber: 204,
                                                            columnNumber: 23
                                                        }, this)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        ref: listEndRef
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                        lineNumber: 216,
                                                        columnNumber: 21
                                                    }, this),
                                                    suggestedProducts.length > 0 && ((_messages_ = messages[messages.length - 1]) === null || _messages_ === void 0 ? void 0 : _messages_.content) !== "Thinking…" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex justify-center pt-2",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                            onClick: ()=>setModalOpen(true),
                                                            className: "bg-green-600 hover:bg-green-700 text-white shadow-md",
                                                            size: "sm",
                                                            children: "View Suggested Products"
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                            lineNumber: 219,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                        lineNumber: 218,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                lineNumber: 202,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                            lineNumber: 201,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-3 border-t bg-white",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                                        ref: inputRef,
                                                        value: input,
                                                        onChange: (e)=>setInput(e.target.value),
                                                        onKeyDown: onKeyDown,
                                                        placeholder: "Type your message…",
                                                        className: "focus-visible:ring-blue-600"
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                        lineNumber: 234,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                        onClick: onSend,
                                                        className: "bg-blue-600 text-white hover:bg-blue-700",
                                                        "aria-label": "Send message",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__["Send"], {
                                                            className: "h-4 w-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                            lineNumber: 243,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                        lineNumber: 242,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                                lineNumber: 233,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                            lineNumber: 232,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                    lineNumber: 199,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                                lineNumber: 198,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                        lineNumber: 183,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$home$2f$product$2d$suggest$2d$modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: modalOpen,
                onClose: ()=>setModalOpen(false),
                suggestedProducts: suggestedProducts,
                allProducts: allProducts,
                cartId: cartId,
                cartItems: cartItems,
                onCartUpdate: handleCartUpdate
            }, void 0, false, {
                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/home/ChatBot.tsx",
                lineNumber: 254,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ChatWidget, "mq4jA/gX5WrDZ3xgH1j0xr5607Y=");
_c = ChatWidget;
var _c;
__turbopack_context__.k.register(_c, "ChatWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=dev_cs160project_food-delivery-system-cs160_08a39cc4._.js.map