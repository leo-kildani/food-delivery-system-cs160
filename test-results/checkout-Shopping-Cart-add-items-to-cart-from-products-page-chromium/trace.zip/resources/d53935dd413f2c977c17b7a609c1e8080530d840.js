(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8e615ddc._.css",
  "static/chunks/dev_cs160project_food-delivery-system-cs160_4d9cad1a._.js"
],
    source: "dynamic"
});
