(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/data:ea1795 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"4079f830a1cc18e7cd64f5bb310278309e94b522f3":"removeCartItem"},"dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/actions.ts",""] */ __turbopack_context__.s([
    "removeCartItem",
    ()=>removeCartItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var removeCartItem = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4079f830a1cc18e7cd64f5bb310278309e94b522f3", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "removeCartItem"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBDYXJ0SXRlbSwgUHJpc21hLCBQcm9kdWN0IH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XG5cbmNvbnN0IGNhcnRXaXRoSXRlbXNBbmRQcm9kdWN0ID0gUHJpc21hLnZhbGlkYXRvcjxQcmlzbWEuQ2FydERlZmF1bHRBcmdzPigpKHtcbiAgaW5jbHVkZToge1xuICAgIGNhcnRJdGVtczoge1xuICAgICAgaW5jbHVkZToge1xuICAgICAgICBwcm9kdWN0OiB0cnVlLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxufSk7XG5cbmV4cG9ydCB0eXBlIENhcnRXaXRoSXRlbXNBbmRQcm9kdWN0ID0gUHJpc21hLkNhcnRHZXRQYXlsb2FkPFxuICB0eXBlb2YgY2FydFdpdGhJdGVtc0FuZFByb2R1Y3Rcbj47XG5leHBvcnQgdHlwZSBTZXJpYWxpemVkQ2FydEl0ZW0gPSBDYXJ0SXRlbSAmIHtcbiAgcHJvZHVjdDogT21pdDxQcm9kdWN0LCBcInByaWNlUGVyVW5pdFwiIHwgXCJ3ZWlnaHRQZXJVbml0XCI+ICYge1xuICAgIHByaWNlUGVyVW5pdDogbnVtYmVyO1xuICAgIHdlaWdodFBlclVuaXQ6IG51bWJlcjtcbiAgfTtcbn07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyQ2FydChcbiAgdXNlcklkOiBzdHJpbmdcbik6IFByb21pc2U8Q2FydFdpdGhJdGVtc0FuZFByb2R1Y3Q+IHtcbiAgLy8gRmlyc3QsIGVuc3VyZSB0aGUgdXNlciBleGlzdHMgaW4gdGhlIGRhdGFiYXNlXG4gIGxldCB1c2VyID0gYXdhaXQgcHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHsgYXV0aElkOiB1c2VySWQgfSxcbiAgfSk7XG5cbiAgaWYgKCF1c2VyKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGxldCBjYXJ0ID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcbiAgICB9LFxuICAgIC4uLmNhcnRXaXRoSXRlbXNBbmRQcm9kdWN0LFxuICB9KTtcblxuICAvLyAgIENyZWF0ZSBhIG5ldyBjYXJ0IGZvciB1c2VyIGlmIGRvZXNuJ3QgZXhpc3RcbiAgaWYgKGNhcnQgPT09IG51bGwpIHtcbiAgICBsZXQgbmV3Q2FydDogUHJpc21hLkNhcnRDcmVhdGVJbnB1dDtcbiAgICBuZXdDYXJ0ID0ge1xuICAgICAgdXNlcjoge1xuICAgICAgICBjb25uZWN0OiB7XG4gICAgICAgICAgaWQ6IHVzZXIuaWQsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG4gICAgY2FydCA9IGF3YWl0IHByaXNtYS5jYXJ0LmNyZWF0ZSh7XG4gICAgICBkYXRhOiBuZXdDYXJ0LFxuICAgICAgLi4uY2FydFdpdGhJdGVtc0FuZFByb2R1Y3QsXG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gY2FydDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbW92ZUNhcnRJdGVtKGNhcnRJZDogbnVtYmVyKSB7XG4gIGF3YWl0IHByaXNtYS5jYXJ0SXRlbS5kZWxldGUoe1xuICAgIHdoZXJlOiB7IGlkOiBjYXJ0SWQgfSxcbiAgfSk7XG5cbiAgcmV2YWxpZGF0ZVBhdGgoXCIvc2hvcHBpbmctY2FydFwiKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcnRJdGVtUXVhbnRpdHkoXG4gIGNhcnRJdGVtSWQ6IG51bWJlcixcbiAgbmV3UXVhbnRpdHk6IG51bWJlclxuKSB7XG4gIGlmIChuZXdRdWFudGl0eSA8IDEpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiUXVhbnRpdHkgbXVzdCBiZSBhdCBsZWFzdCAxXCIgfTtcbiAgfVxuXG4gIGF3YWl0IHByaXNtYS5jYXJ0SXRlbS51cGRhdGUoe1xuICAgIHdoZXJlOiB7IGlkOiBjYXJ0SXRlbUlkIH0sXG4gICAgZGF0YTogeyBxdWFudGl0eTogbmV3UXVhbnRpdHkgfSxcbiAgfSk7XG5cbiAgcmV2YWxpZGF0ZVBhdGgoXCIvc2hvcHBpbmctY2FydFwiKTtcbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYmF0Y2hVcGRhdGVDYXJ0SXRlbXMoXG4gIHVwZGF0ZXM6IHsgaWQ6IG51bWJlcjsgcXVhbnRpdHk6IG51bWJlciB9W11cbikge1xuICBhd2FpdCBwcmlzbWEuJHRyYW5zYWN0aW9uKFxuICAgIHVwZGF0ZXMubWFwKCh7IGlkLCBxdWFudGl0eSB9KSA9PlxuICAgICAgcHJpc21hLmNhcnRJdGVtLnVwZGF0ZSh7XG4gICAgICAgIHdoZXJlOiB7IGlkIH0sXG4gICAgICAgIGRhdGE6IHsgcXVhbnRpdHkgfSxcbiAgICAgIH0pXG4gICAgKVxuICApO1xuXG4gIHJldmFsaWRhdGVQYXRoKFwiL3Nob3BwaW5nLWNhcnRcIik7XG4gIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoidVZBZ0VzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/data:1f26a8 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"60b9bf43384317f78b65f375ea68b080324a730910":"updateCartItemQuantity"},"dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/actions.ts",""] */ __turbopack_context__.s([
    "updateCartItemQuantity",
    ()=>updateCartItemQuantity
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var updateCartItemQuantity = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("60b9bf43384317f78b65f375ea68b080324a730910", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateCartItemQuantity"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzZXJ2ZXJcIjtcblxuaW1wb3J0IHByaXNtYSBmcm9tIFwiQC9saWIvcHJpc21hXCI7XG5pbXBvcnQgeyBDYXJ0SXRlbSwgUHJpc21hLCBQcm9kdWN0IH0gZnJvbSBcIkBwcmlzbWEvY2xpZW50XCI7XG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XG5cbmNvbnN0IGNhcnRXaXRoSXRlbXNBbmRQcm9kdWN0ID0gUHJpc21hLnZhbGlkYXRvcjxQcmlzbWEuQ2FydERlZmF1bHRBcmdzPigpKHtcbiAgaW5jbHVkZToge1xuICAgIGNhcnRJdGVtczoge1xuICAgICAgaW5jbHVkZToge1xuICAgICAgICBwcm9kdWN0OiB0cnVlLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxufSk7XG5cbmV4cG9ydCB0eXBlIENhcnRXaXRoSXRlbXNBbmRQcm9kdWN0ID0gUHJpc21hLkNhcnRHZXRQYXlsb2FkPFxuICB0eXBlb2YgY2FydFdpdGhJdGVtc0FuZFByb2R1Y3Rcbj47XG5leHBvcnQgdHlwZSBTZXJpYWxpemVkQ2FydEl0ZW0gPSBDYXJ0SXRlbSAmIHtcbiAgcHJvZHVjdDogT21pdDxQcm9kdWN0LCBcInByaWNlUGVyVW5pdFwiIHwgXCJ3ZWlnaHRQZXJVbml0XCI+ICYge1xuICAgIHByaWNlUGVyVW5pdDogbnVtYmVyO1xuICAgIHdlaWdodFBlclVuaXQ6IG51bWJlcjtcbiAgfTtcbn07XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyQ2FydChcbiAgdXNlcklkOiBzdHJpbmdcbik6IFByb21pc2U8Q2FydFdpdGhJdGVtc0FuZFByb2R1Y3Q+IHtcbiAgLy8gRmlyc3QsIGVuc3VyZSB0aGUgdXNlciBleGlzdHMgaW4gdGhlIGRhdGFiYXNlXG4gIGxldCB1c2VyID0gYXdhaXQgcHJpc21hLnVzZXIuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHsgYXV0aElkOiB1c2VySWQgfSxcbiAgfSk7XG5cbiAgaWYgKCF1c2VyKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJVc2VyIG5vdCBmb3VuZFwiKTtcbiAgfVxuXG4gIGxldCBjYXJ0ID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlci5pZCxcbiAgICB9LFxuICAgIC4uLmNhcnRXaXRoSXRlbXNBbmRQcm9kdWN0LFxuICB9KTtcblxuICAvLyAgIENyZWF0ZSBhIG5ldyBjYXJ0IGZvciB1c2VyIGlmIGRvZXNuJ3QgZXhpc3RcbiAgaWYgKGNhcnQgPT09IG51bGwpIHtcbiAgICBsZXQgbmV3Q2FydDogUHJpc21hLkNhcnRDcmVhdGVJbnB1dDtcbiAgICBuZXdDYXJ0ID0ge1xuICAgICAgdXNlcjoge1xuICAgICAgICBjb25uZWN0OiB7XG4gICAgICAgICAgaWQ6IHVzZXIuaWQsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH07XG4gICAgY2FydCA9IGF3YWl0IHByaXNtYS5jYXJ0LmNyZWF0ZSh7XG4gICAgICBkYXRhOiBuZXdDYXJ0LFxuICAgICAgLi4uY2FydFdpdGhJdGVtc0FuZFByb2R1Y3QsXG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gY2FydDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbW92ZUNhcnRJdGVtKGNhcnRJZDogbnVtYmVyKSB7XG4gIGF3YWl0IHByaXNtYS5jYXJ0SXRlbS5kZWxldGUoe1xuICAgIHdoZXJlOiB7IGlkOiBjYXJ0SWQgfSxcbiAgfSk7XG5cbiAgcmV2YWxpZGF0ZVBhdGgoXCIvc2hvcHBpbmctY2FydFwiKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcnRJdGVtUXVhbnRpdHkoXG4gIGNhcnRJdGVtSWQ6IG51bWJlcixcbiAgbmV3UXVhbnRpdHk6IG51bWJlclxuKSB7XG4gIGlmIChuZXdRdWFudGl0eSA8IDEpIHtcbiAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IFwiUXVhbnRpdHkgbXVzdCBiZSBhdCBsZWFzdCAxXCIgfTtcbiAgfVxuXG4gIGF3YWl0IHByaXNtYS5jYXJ0SXRlbS51cGRhdGUoe1xuICAgIHdoZXJlOiB7IGlkOiBjYXJ0SXRlbUlkIH0sXG4gICAgZGF0YTogeyBxdWFudGl0eTogbmV3UXVhbnRpdHkgfSxcbiAgfSk7XG5cbiAgcmV2YWxpZGF0ZVBhdGgoXCIvc2hvcHBpbmctY2FydFwiKTtcbiAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYmF0Y2hVcGRhdGVDYXJ0SXRlbXMoXG4gIHVwZGF0ZXM6IHsgaWQ6IG51bWJlcjsgcXVhbnRpdHk6IG51bWJlciB9W11cbikge1xuICBhd2FpdCBwcmlzbWEuJHRyYW5zYWN0aW9uKFxuICAgIHVwZGF0ZXMubWFwKCh7IGlkLCBxdWFudGl0eSB9KSA9PlxuICAgICAgcHJpc21hLmNhcnRJdGVtLnVwZGF0ZSh7XG4gICAgICAgIHdoZXJlOiB7IGlkIH0sXG4gICAgICAgIGRhdGE6IHsgcXVhbnRpdHkgfSxcbiAgICAgIH0pXG4gICAgKVxuICApO1xuXG4gIHJldmFsaWRhdGVQYXRoKFwiL3Nob3BwaW5nLWNhcnRcIik7XG4gIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiK1ZBd0VzQiJ9
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ShoppingCartClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$shopping$2d$cart$2f$data$3a$ea1795__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/data:ea1795 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$shopping$2d$cart$2f$data$3a$1f26a8__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/data:1f26a8 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function ShoppingCartClient(param) {
    let { initialCartItems } = param;
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [cartItems, setCartItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCartItems);
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    const [pendingActions, setPendingActions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [modifiedQuantities, setModifiedQuantities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Map());
    const handleQuantityChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShoppingCartClient.useCallback[handleQuantityChange]": (cartItemId, newQuantity)=>{
            if (newQuantity < 1) return;
            // Update local state only
            setCartItems({
                "ShoppingCartClient.useCallback[handleQuantityChange]": (prev)=>prev.map({
                        "ShoppingCartClient.useCallback[handleQuantityChange]": (item)=>item.id === cartItemId ? {
                                ...item,
                                quantity: newQuantity
                            } : item
                    }["ShoppingCartClient.useCallback[handleQuantityChange]"])
            }["ShoppingCartClient.useCallback[handleQuantityChange]"]);
            // Track that this item has been modified
            setModifiedQuantities({
                "ShoppingCartClient.useCallback[handleQuantityChange]": (prev)=>{
                    const next = new Map(prev);
                    next.set(cartItemId, newQuantity);
                    return next;
                }
            }["ShoppingCartClient.useCallback[handleQuantityChange]"]);
        }
    }["ShoppingCartClient.useCallback[handleQuantityChange]"], []);
    const handleSaveQuantity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShoppingCartClient.useCallback[handleSaveQuantity]": (cartItemId, newQuantity)=>{
            setPendingActions({
                "ShoppingCartClient.useCallback[handleSaveQuantity]": (prev)=>new Set(prev).add(cartItemId)
            }["ShoppingCartClient.useCallback[handleSaveQuantity]"]);
            startTransition({
                "ShoppingCartClient.useCallback[handleSaveQuantity]": async ()=>{
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$shopping$2d$cart$2f$data$3a$1f26a8__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateCartItemQuantity"])(cartItemId, newQuantity);
                    // Remove from modified quantities after saving
                    setModifiedQuantities({
                        "ShoppingCartClient.useCallback[handleSaveQuantity]": (prev)=>{
                            const next = new Map(prev);
                            next.delete(cartItemId);
                            return next;
                        }
                    }["ShoppingCartClient.useCallback[handleSaveQuantity]"]);
                    setPendingActions({
                        "ShoppingCartClient.useCallback[handleSaveQuantity]": (prev)=>{
                            const next = new Set(prev);
                            next.delete(cartItemId);
                            return next;
                        }
                    }["ShoppingCartClient.useCallback[handleSaveQuantity]"]);
                    router.refresh();
                }
            }["ShoppingCartClient.useCallback[handleSaveQuantity]"]);
        }
    }["ShoppingCartClient.useCallback[handleSaveQuantity]"], [
        router
    ]);
    const handleRemove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ShoppingCartClient.useCallback[handleRemove]": (cartItemId)=>{
            // Optimistic removal
            setCartItems({
                "ShoppingCartClient.useCallback[handleRemove]": (prev)=>prev.filter({
                        "ShoppingCartClient.useCallback[handleRemove]": (item)=>item.id !== cartItemId
                    }["ShoppingCartClient.useCallback[handleRemove]"])
            }["ShoppingCartClient.useCallback[handleRemove]"]);
            setPendingActions({
                "ShoppingCartClient.useCallback[handleRemove]": (prev)=>new Set(prev).add(cartItemId)
            }["ShoppingCartClient.useCallback[handleRemove]"]);
            startTransition({
                "ShoppingCartClient.useCallback[handleRemove]": async ()=>{
                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$shopping$2d$cart$2f$data$3a$ea1795__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["removeCartItem"])(cartItemId);
                    setPendingActions({
                        "ShoppingCartClient.useCallback[handleRemove]": (prev)=>{
                            const next = new Set(prev);
                            next.delete(cartItemId);
                            return next;
                        }
                    }["ShoppingCartClient.useCallback[handleRemove]"]);
                    router.refresh();
                }
            }["ShoppingCartClient.useCallback[handleRemove]"]);
        }
    }["ShoppingCartClient.useCallback[handleRemove]"], [
        router
    ]);
    // Calculate total cost, total weight 
    let totalCartCost = 0;
    let totalCartWeight = 0;
    let itemCount = 0;
    cartItems.forEach((cartItem)=>{
        itemCount++;
        const price = cartItem.product.pricePerUnit;
        totalCartCost += price * cartItem.quantity;
        totalCartWeight += cartItem.product.weightPerUnit * cartItem.quantity;
    });
    // 2 decimal places for totalWeight
    let totalCartWeight2Digits = totalCartWeight.toFixed(2);
    // Calculate delievery Fee
    let deliveryFee = 0;
    if (totalCartWeight > 20) {
        deliveryFee = 10;
        totalCartCost += 10;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50 py-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-7xl px-4 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "mb-8 text-3xl font-bold text-gray-900",
                    children: "Shopping Cart"
                }, void 0, false, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                    lineNumber: 117,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 space-y-4",
                            children: cartItems.map((cartItem)=>{
                                const p = cartItem.product;
                                const price = p.pricePerUnit;
                                const subtotal = price * cartItem.quantity;
                                const subWeight = cartItem.product.weightPerUnit * cartItem.quantity;
                                const subWeight2Digits = subWeight.toFixed(2);
                                const isActionPending = pendingActions.has(cartItem.id);
                                const hasUnsavedChanges = modifiedQuantities.has(cartItem.id);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "rounded-lg border bg-white p-4 shadow-sm relative transition-opacity ".concat(isActionPending ? "opacity-60" : ""),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>handleRemove(cartItem.id),
                                            disabled: isActionPending,
                                            className: "absolute top-4 right-4 bg-red-500 hover:bg-red-600 disabled:bg-red-300 text-white px-4 py-2 rounded-md transition-colors flex items-center justify-center gap-2",
                                            "aria-label": "Remove item",
                                            children: [
                                                isActionPending && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                    className: "h-4 w-4 animate-spin"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                    lineNumber: 146,
                                                    columnNumber: 23
                                                }, this),
                                                "Remove"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                            lineNumber: 139,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4 pr-12",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-shrink-0",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative h-32 w-32 overflow-hidden rounded-lg border border-gray-200 bg-gray-100",
                                                        children: p.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                            src: p.imageUrl,
                                                            alt: p.name,
                                                            className: "h-full w-full object-cover"
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                            lineNumber: 155,
                                                            columnNumber: 27
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex h-full w-full items-center justify-center text-gray-400",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm",
                                                                children: "No image"
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                lineNumber: 162,
                                                                columnNumber: 29
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                            lineNumber: 161,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 153,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                    lineNumber: 152,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: "mb-1 text-lg font-semibold",
                                                            children: p.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                            lineNumber: 168,
                                                            columnNumber: 23
                                                        }, this),
                                                        p.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "mb-2 text-sm text-gray-600",
                                                            children: p.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-1 text-sm",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-medium",
                                                                            children: "Category:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                            lineNumber: 177,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        " ",
                                                                        p.category
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                    lineNumber: 176,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-medium",
                                                                            children: "Weight:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                            lineNumber: 181,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        " ",
                                                                        subWeight2Digits
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                    lineNumber: 180,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2 py-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "font-medium",
                                                                            children: "Quantity:"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                            lineNumber: 187,
                                                                            columnNumber: 27
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center gap-2",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "flex items-center gap-1",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                                            onClick: ()=>handleQuantityChange(cartItem.id, cartItem.quantity - 1),
                                                                                            variant: "outline",
                                                                                            size: "icon",
                                                                                            className: "h-8 w-8",
                                                                                            disabled: cartItem.quantity <= 1 || isActionPending,
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Minus$3e$__["Minus"], {
                                                                                                className: "h-4 w-4"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                                lineNumber: 204,
                                                                                                columnNumber: 33
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                            lineNumber: 190,
                                                                                            columnNumber: 31
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                            className: "w-12 text-center font-semibold",
                                                                                            children: cartItem.quantity
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                            lineNumber: 207,
                                                                                            columnNumber: 31
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                                            onClick: ()=>handleQuantityChange(cartItem.id, cartItem.quantity + 1),
                                                                                            variant: "outline",
                                                                                            size: "icon",
                                                                                            className: "h-8 w-8",
                                                                                            disabled: isActionPending,
                                                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                                                                className: "h-4 w-4"
                                                                                            }, void 0, false, {
                                                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                                lineNumber: 223,
                                                                                                columnNumber: 33
                                                                                            }, this)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                            lineNumber: 211,
                                                                                            columnNumber: 31
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                    lineNumber: 189,
                                                                                    columnNumber: 29
                                                                                }, this),
                                                                                hasUnsavedChanges && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                                                    onClick: ()=>handleSaveQuantity(cartItem.id, cartItem.quantity),
                                                                                    disabled: isActionPending,
                                                                                    size: "sm",
                                                                                    className: "bg-green-600 hover:bg-green-700",
                                                                                    children: isActionPending ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"], {
                                                                                        className: "h-4 w-4 animate-spin"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                        lineNumber: 241,
                                                                                        columnNumber: 35
                                                                                    }, this) : "Save"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                                    lineNumber: 229,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                            lineNumber: 188,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                    lineNumber: 186,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-base font-semibold",
                                                                    children: [
                                                                        "$",
                                                                        subtotal.toFixed(2)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                    lineNumber: 250,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                            lineNumber: 175,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                    lineNumber: 167,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                            lineNumber: 150,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, cartItem.id, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                    lineNumber: 132,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                            lineNumber: 121,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-80 shrink-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "sticky top-8 rounded-lg border bg-white p-6 shadow-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "mb-4 text-xl font-bold",
                                        children: "Cart Summary"
                                    }, void 0, false, {
                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                        lineNumber: 264,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between text-sm text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Items:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 267,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: itemCount
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 268,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                lineNumber: 266,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between text-sm text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Total Weight:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 271,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: totalCartWeight2Digits
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 272,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                lineNumber: 270,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between text-sm text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "Delivery Fee:",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                lineNumber: 276,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-[13px] text-gray-400 italic",
                                                                children: "A cart weight over 20lbs will have a $10 delievery fee."
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                                lineNumber: 277,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 275,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "$",
                                                            deliveryFee
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 279,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                lineNumber: 274,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between text-lg border-t pt-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold",
                                                        children: "Subtotal:"
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 282,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold text-green-600",
                                                        children: [
                                                            "$",
                                                            totalCartCost.toFixed(2)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                        lineNumber: 283,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                lineNumber: 281,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                        lineNumber: 265,
                                        columnNumber: 15
                                    }, this),
                                    modifiedQuantities.size > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-4 rounded-md bg-yellow-50 border border-yellow-200 p-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-yellow-800",
                                            children: "You have unsaved changes. Click Save to update quantities."
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                            lineNumber: 290,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                        lineNumber: 289,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-6",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            asChild: true,
                                            className: "w-full",
                                            disabled: isPending || modifiedQuantities.size > 0,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: "/checkout",
                                                children: "Proceed to Checkout"
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                                lineNumber: 301,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                            lineNumber: 296,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                        lineNumber: 295,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                                lineNumber: 263,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                            lineNumber: 262,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
            lineNumber: 116,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/shopping-cart/cart-client.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}
_s(ShoppingCartClient, "6MFqkZysx4wRckJDQLb4m67q2bA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"]
    ];
});
_c = ShoppingCartClient;
var _c;
__turbopack_context__.k.register(_c, "ShoppingCartClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Minus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ]
];
const Minus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("minus", __iconNode);
;
 //# sourceMappingURL=minus.js.map
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript) <export default as Minus>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Minus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$minus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/minus.js [app-client] (ecmascript)");
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */ __turbopack_context__.s([
    "__iconNode",
    ()=>__iconNode,
    "default",
    ()=>Plus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/createLucideIcon.js [app-client] (ecmascript)");
;
const __iconNode = [
    [
        "path",
        {
            d: "M5 12h14",
            key: "1ays0h"
        }
    ],
    [
        "path",
        {
            d: "M12 5v14",
            key: "s699le"
        }
    ]
];
const Plus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$createLucideIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("plus", __iconNode);
;
 //# sourceMappingURL=plus.js.map
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Plus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript)");
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Loader2",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript)");
}),
"[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/navigation.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = __turbopack_context__.r("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/client/components/navigation.js [app-client] (ecmascript)");
}),
]);

//# sourceMappingURL=dev_cs160project_food-delivery-system-cs160_95009118._.js.map