(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/dev_cs160project_food-delivery-system-cs160_app_(user)_checkout_62e31a7a._.js"
],
    source: "dynamic"
});
