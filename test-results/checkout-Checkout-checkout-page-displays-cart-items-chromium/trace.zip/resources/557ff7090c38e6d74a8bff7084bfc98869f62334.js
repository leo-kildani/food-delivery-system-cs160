(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/78f1f_820a292c._.js",
  "static/chunks/dev_cs160project_food-delivery-system-cs160_ab3f0edf._.js"
],
    source: "dynamic"
});
