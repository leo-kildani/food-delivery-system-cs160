(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/data:df7476 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

/* __next_internal_action_entry_do_not_use__ [{"606b67f7b1459a32ac0737c09afc50e2ebff0ff430":"checkoutAction"},"dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/actions.ts",""] */ __turbopack_context__.s([
    "checkoutAction",
    ()=>checkoutAction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
"use turbopack no side effects";
;
var checkoutAction = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("606b67f7b1459a32ac0737c09afc50e2ebff0ff430", __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "checkoutAction"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcic7XG5cbmltcG9ydCBwcmlzbWEgZnJvbSAnQC9saWIvcHJpc21hJztcbmltcG9ydCB7Y3JlYXRlQ2xpZW50fSBmcm9tICdAL2xpYi9zdXBhYmFzZS9zZXJ2ZXInO1xuaW1wb3J0IHtEZWxpdmVyeUFkZHJlc3MsIFByaXNtYSwgUHJvZHVjdCwgT3JkZXJ9IGZyb20gJ0BwcmlzbWEvY2xpZW50JztcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSc7XG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbic7XG5cbi8vIERlZmluZSBxdWVyeSB0eXBlIGZvciBDYXJ0IHdpdGggQ2FydGl0ZW0gYW5kIHByb2R1Y3RzXG5jb25zdCBjYXJ0V2l0aEl0ZW1zQW5kUHJvZHVjdCA9IFByaXNtYS52YWxpZGF0b3I8UHJpc21hLkNhcnREZWZhdWx0QXJncz4oKSh7XG4gIGluY2x1ZGU6IHtcbiAgICBjYXJ0SXRlbXM6IHtcbiAgICAgIGluY2x1ZGU6IHtcbiAgICAgICAgcHJvZHVjdDogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn0pO1xuXG4vLyBEZWZpbmUgcXVlcnkgcmV0dXJuIHR5cGUgZm9yIHR5cGUgY2hlY2tpbmcgKFRTKVxuZXhwb3J0IHR5cGUgQ2FydFdpdGhJdGVtc0FuZFByb2R1Y3QgPVxuICAgIFByaXNtYS5DYXJ0R2V0UGF5bG9hZDx0eXBlb2YgY2FydFdpdGhJdGVtc0FuZFByb2R1Y3Q+O1xuXG5hc3luYyBmdW5jdGlvbiBnZXRVc2VySWQoKSB7XG4gIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KCk7XG4gIGNvbnN0IHtcbiAgICBkYXRhOiB7dXNlcn0sXG4gIH0gPSBhd2FpdCBzdXBhYmFzZS5hdXRoLmdldFVzZXIoKTtcbiAgbGV0IHBlcnNvbmFsX3VzZXIgPSBhd2FpdCBwcmlzbWEudXNlci5maW5kVW5pcXVlKHtcbiAgICB3aGVyZToge2F1dGhJZDogdXNlcj8uaWR9LFxuICB9KTtcbiAgaWYgKCFwZXJzb25hbF91c2VyPy5pZCkge1xuICAgIHRocm93IG5ldyBFcnJvcignVXNlciBub3QgZm91bmQgb3IgdXNlciBJRCBpcyB1bmRlZmluZWQnKTtcbiAgfVxuICByZXR1cm4gcGVyc29uYWxfdXNlci5pZDtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRDYXJ0SXRlbXMoKSB7XG4gIC8vIGZpcnN0IGdldCB1c2VySWRcbiAgLy8gZ2V0IGNhcnQgaWQgZnJvbSB1c2VySWQgZnJvbSB0aGUgY2FydCB0YWJsZVxuICAvLyByZXR1cm4gYWxsIGNhcnRJdGVtcyB3aXRoIGEgY2VydGFpbiBjYXJ0SURcbiAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICBsZXQgY2FydElkID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7d2hlcmU6IHt1c2VySWQ6IHVzZXJJZH19KTtcbiAgaWYgKGNhcnRJZCA9PSBudWxsKSB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGxldCBjYXJ0ID0gYXdhaXQgcHJpc21hLmNhcnQuZmluZFVuaXF1ZSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgIH0sXG4gICAgLi4uY2FydFdpdGhJdGVtc0FuZFByb2R1Y3QsXG4gIH0pO1xuICBpZiAoIWNhcnQpIHtcbiAgICByZXR1cm4gW107XG4gIH1cbiAgbGV0IHRvUmV0dXJuID0gY2FydD8uY2FydEl0ZW1zLm1hcChcbiAgICAgIChpdGVtKSA9PiB7cmV0dXJuICh7XG4gICAgICAgIC4uLml0ZW0sXG4gICAgICAgIHByb2R1Y3Q6IHtcbiAgICAgICAgICAuLi5pdGVtLnByb2R1Y3QsXG4gICAgICAgICAgcHJpY2VQZXJVbml0OiBpdGVtLnByb2R1Y3QucHJpY2VQZXJVbml0LnRvTnVtYmVyKCksXG4gICAgICAgICAgd2VpZ2h0UGVyVW5pdDogaXRlbS5wcm9kdWN0LndlaWdodFBlclVuaXQudG9OdW1iZXIoKVxuICAgICAgICB9XG4gICAgICB9KX0pXG5cbiAgcmV0dXJuIHRvUmV0dXJuO1xufVxuXG5leHBvcnQgdHlwZSBDaGVja291dFN0YXRlID0ge1xuICBvaz86IGJvb2xlYW47XG4gIGZvcm1FcnJvcj86IHN0cmluZztcbiAgZmllbGRFcnJvcnM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmdbXT47XG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWRkcmVzc2VzKCk6IFByb21pc2U8RGVsaXZlcnlBZGRyZXNzW10+IHtcbiAgbGV0IHVzZXJJZCA9IGF3YWl0IGdldFVzZXJJZCgpO1xuICBsZXQgYWRkcmVzc2VzID0gYXdhaXQgcHJpc21hLmRlbGl2ZXJ5QWRkcmVzcy5maW5kTWFueSh7XG4gICAgd2hlcmU6IHtcbiAgICAgIHVzZXJJZDogdXNlcklkLFxuICAgIH1cbiAgfVxuICApXG4gIHJldHVybiBhZGRyZXNzZXM7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjaGVja291dEFjdGlvbihcbiAgICBwcmV2U3RhdGU6IENoZWNrb3V0U3RhdGUsIGZvcm1EYXRhOiBGb3JtRGF0YSk6IFByb21pc2U8Q2hlY2tvdXRTdGF0ZT4ge1xuICB0cnkge1xuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXNKc29uID0gZm9ybURhdGEuZ2V0KCdzZWxlY3RlZEl0ZW1zJykgYXMgc3RyaW5nO1xuICAgIGNvbnN0IHNlbGVjdGVkSXRlbXMgPSBKU09OLnBhcnNlKHNlbGVjdGVkSXRlbXNKc29uKTtcbiAgICBjb25zdCBzZWxlY3RlZEFkZHJlc3NJZCA9IGZvcm1EYXRhLmdldCgnc2VsZWN0ZWRBZGRyZXNzSWQnKSBhcyBzdHJpbmc7XG5cbiAgICBsZXQgdXNlcklkID0gYXdhaXQgZ2V0VXNlcklkKCk7XG4gICAgbGV0IGNhcnQgPSBhd2FpdCBwcmlzbWEuY2FydC5maW5kVW5pcXVlKHsgd2hlcmU6IHsgdXNlcklkOiB1c2VySWQgfSB9KTtcbiAgICBsZXQgYWRkcmVzc2VzID0gYXdhaXQgZ2V0QWRkcmVzc2VzKCk7XG4gICAgaWYgKGFkZHJlc3Nlcy5sZW5ndGggPD0gMCkge1xuICAgICAgcmV0dXJuIHsgZm9ybUVycm9yOiBcIllvdSBkbyBub3QgaGF2ZSBhbiBhZGRyZXNzIHNldFwiIH07XG4gICAgfVxuICAgIFxuICAgIGNvbnN0IHNlbGVjdGVkQWRkcmVzcyA9IGFkZHJlc3Nlcy5maW5kKGFkZHIgPT4gYWRkci5pZCA9PT0gcGFyc2VJbnQoc2VsZWN0ZWRBZGRyZXNzSWQpKTtcbiAgICBpZiAoIXNlbGVjdGVkQWRkcmVzcykge1xuICAgICAgcmV0dXJuIHsgZm9ybUVycm9yOiBcIlBsZWFzZSBzZWxlY3QgYSB2YWxpZCBkZWxpdmVyeSBhZGRyZXNzXCIgfTtcbiAgICB9XG4gICAgXG4gICAgY29uc3Qgb3JkZXIgPSBhd2FpdCBwcmlzbWEub3JkZXIuY3JlYXRlKHtcbiAgICAgIGRhdGE6IHtcbiAgICAgICAgdXNlcklkOiB1c2VySWQsXG4gICAgICAgIHN0YXR1czogJ1BFTkRJTkcnLFxuICAgICAgICB0b0FkZHJlc3M6IHNlbGVjdGVkQWRkcmVzcy5hZGRyZXNzLCBcbiAgICAgICAgY3JlYXRlZEF0OiBuZXcgRGF0ZSgpXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGNvbnN0IHByb2R1Y3RJZHMgPSBzZWxlY3RlZEl0ZW1zLm1hcCgoaXRlbTogYW55KSA9PiBpdGVtLnByb2R1Y3RJZCk7XG5cbiAgICBjb25zdCBvcmRlckl0ZW1zID0gYXdhaXQgcHJpc21hLm9yZGVySXRlbS5jcmVhdGVNYW55KHtcbiAgICAgIGRhdGE6IHNlbGVjdGVkSXRlbXMubWFwKChpdGVtOiBhbnkpID0+ICh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yZGVySWQ6IG9yZGVyLmlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9kdWN0SWQ6IGl0ZW0ucHJvZHVjdElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBxdWFudGl0eTogaXRlbS5xdWFudGl0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJpY2VQZXJVbml0OiBpdGVtLnByaWNlUGVyVW5pdCwgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdlaWdodFBlclVuaXQ6IGl0ZW0ud2VpZ2h0UGVyVW5pdFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpLFxuICAgIH0pO1xuICAgIC8vIGNyZWF0ZSBvcmRlciBpdGVtcyB3aXRoIHRoZSBjb3JyZWN0IG9yZGVyIElEXG4gICAgLy8gcmVtb3ZlIHNlbGVjdGVkSXRlbXMgZnJvbSByZWFsQ2FydCBhbmQgdXBkYXRlIGNhcnRcbiAgICBjb25zdCByZW1vdmVfaXRlbXMgPSBhd2FpdCBwcmlzbWEuY2FydEl0ZW0uZGVsZXRlTWFueSh7XG4gICAgICB3aGVyZToge2NhcnRJZDogY2FydD8uaWQsIHByb2R1Y3RJZDoge2luIDogcHJvZHVjdElkc319LFxuICAgIH0pO1xuXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5sb2coJ3NvbWUgZXJyb3I6JywgZXJyb3IpO1xuICAgIHJldHVybiB7Zm9ybUVycm9yOiAnQ2hlY2tvdXQgZmFpbGVkLCBzb21lIHByb2JsZW0gb2NjdXJlZCd9O1xuICB9XG4gIHJldmFsaWRhdGVQYXRoKCcvaG9tZScpO1xuICByZWRpcmVjdCgnL2hvbWUnKVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJrVkFvRnNCIn0=
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CheckoutComponent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$df7476__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/data:df7476 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function CheckoutComponent(param) {
    let { initialCartItems, initialAddresses } = param;
    var _initialAddresses_;
    _s();
    const [checkoutState, checkoutFormAction, checkoutPending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"])(__TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$app$2f28$user$292f$checkout$2f$data$3a$df7476__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["checkoutAction"], {});
    const [cartItems, setCartItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCartItems); // cart data retrieved from database
    const [selectedItems, setSelectedItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set()); // set of indices that are selected
    const [quantities, setQuantities] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialCartItems.reduce({
        "CheckoutComponent.useState": (acc, item, idx)=>{
            acc[idx] = item.quantity;
            return acc;
        }
    }["CheckoutComponent.useState"], {}));
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [addresses, setAddresses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialAddresses);
    const [selectedAddressId, setSelectedAddressId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(((_initialAddresses_ = initialAddresses[0]) === null || _initialAddresses_ === void 0 ? void 0 : _initialAddresses_.id) || null);
    const [isAddressDropdownOpen, setIsAddressDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleItemSelection = (idx, checked)=>{
        const newSelected = new Set(selectedItems);
        if (checked) {
            newSelected.add(idx);
        } else {
            newSelected.delete(idx);
        }
        setSelectedItems(newSelected); //updating the setSelectedItems state
    };
    const selectedItemsData = cartItems.map((item, idx)=>({
            ...item,
            idx,
            quantity: item.quantity || 0
        })).filter((item, idx)=>selectedItems.has(idx) && item.quantity > 0);
    // calculate only the selected items price and weighht
    const handleQuantityChange = (change, idx)=>{
        setQuantities((prev)=>({
                ...prev,
                [idx]: Math.max(0, prev[idx] + change)
            }));
        console.log(quantities);
    };
    const handleAddressSelect = (addressId)=>{
        setSelectedAddressId(addressId);
        setIsAddressDropdownOpen(false);
    };
    const selectedAddress = addresses.find((addr)=>addr.id === selectedAddressId);
    // Close dropdown when clicking outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CheckoutComponent.useEffect": ()=>{
            const handleClickOutside = {
                "CheckoutComponent.useEffect.handleClickOutside": (event)=>{
                    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                        setIsAddressDropdownOpen(false);
                    }
                }
            }["CheckoutComponent.useEffect.handleClickOutside"];
            if (isAddressDropdownOpen) {
                document.addEventListener('mousedown', handleClickOutside);
            }
            return ({
                "CheckoutComponent.useEffect": ()=>{
                    document.removeEventListener('mousedown', handleClickOutside);
                }
            })["CheckoutComponent.useEffect"];
        }
    }["CheckoutComponent.useEffect"], [
        isAddressDropdownOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-4xl mx-auto p-6 bg-gray-50 min-h-screen",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-lg shadow-sm",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "border-b border-gray-200 px-6 py-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-2xl font-bold text-gray-900",
                        children: "Checkout"
                    }, void 0, false, {
                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    action: checkoutFormAction,
                    className: "p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "hidden",
                            name: "selectedItems",
                            value: JSON.stringify(selectedItemsData.map((item)=>{
                                var _item_product, _item_product1, _item_product2;
                                var _item_product_pricePerUnit, _item_product_weightPerUnit;
                                return {
                                    productId: (_item_product = item.product) === null || _item_product === void 0 ? void 0 : _item_product.id,
                                    quantity: quantities[item.idx],
                                    pricePerUnit: Number((_item_product_pricePerUnit = (_item_product1 = item.product) === null || _item_product1 === void 0 ? void 0 : _item_product1.pricePerUnit) !== null && _item_product_pricePerUnit !== void 0 ? _item_product_pricePerUnit : 0),
                                    weightPerUnit: Number((_item_product_weightPerUnit = (_item_product2 = item.product) === null || _item_product2 === void 0 ? void 0 : _item_product2.weightPerUnit) !== null && _item_product_weightPerUnit !== void 0 ? _item_product_weightPerUnit : 0)
                                };
                            }))
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "hidden",
                            name: "selectedAddressId",
                            value: selectedAddressId || ""
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: cartItems.map((item, idx)=>{
                                var _item_product_pricePerUnit, _item_product_weightPerUnit;
                                return item.product ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            checked: selectedItems.has(idx),
                                            onChange: (e)=>handleItemSelection(idx, e.target.checked),
                                            className: "h-5 w-5 text-blue-600 rounded border-gray-300 focus:ring-blue-500 mr-4"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 147,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-shrink-0 mr-4",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative h-20 w-20 overflow-hidden rounded-lg border border-gray-200 bg-gray-100",
                                                children: item.product.imageUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: item.product.imageUrl,
                                                    alt: item.product.name,
                                                    className: "h-full w-full object-cover"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 160,
                                                    columnNumber: 27
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex h-full w-full items-center justify-center text-gray-400",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-8 h-8",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 1.5,
                                                            d: "M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 173,
                                                            columnNumber: 31
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                        lineNumber: 167,
                                                        columnNumber: 29
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 166,
                                                    columnNumber: 27
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                lineNumber: 158,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 157,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 min-w-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-semibold text-gray-900 mb-1",
                                                    children: item.product.name
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 185,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex flex-col sm:flex-row sm:items-center sm:space-x-6 text-sm text-gray-600",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "font-medium text-green-600",
                                                            children: [
                                                                "$",
                                                                ((_item_product_pricePerUnit = item.product.pricePerUnit) === null || _item_product_pricePerUnit === void 0 ? void 0 : _item_product_pricePerUnit.toNumber) ? item.product.pricePerUnit.toNumber().toFixed(2) : item.product.pricePerUnit
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 189,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: [
                                                                "Weight:",
                                                                " ",
                                                                ((_item_product_weightPerUnit = item.product.weightPerUnit) === null || _item_product_weightPerUnit === void 0 ? void 0 : _item_product_weightPerUnit.toNumber) ? item.product.weightPerUnit.toNumber() : item.product.weightPerUnit,
                                                                "g"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 195,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800",
                                                            children: item.product.category
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 202,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 184,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center space-x-3 ml-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>handleQuantityChange(-1, idx),
                                                    className: "w-8 h-8 rounded-full border border-gray-300 bg-white hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:outline-none flex items-center justify-center text-gray-600 hover:text-gray-900 transition-colors",
                                                    children: "−"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 209,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "w-8 text-center font-semibold text-gray-900",
                                                    children: quantities[idx]
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 216,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    type: "button",
                                                    onClick: ()=>handleQuantityChange(1, idx),
                                                    className: "w-8 h-8 rounded-full border border-gray-300 bg-white hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:outline-none flex items-center justify-center text-gray-600 hover:text-gray-900 transition-colors",
                                                    children: "+"
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 219,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 208,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, idx, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 143,
                                    columnNumber: 19
                                }, this) : null;
                            })
                        }, void 0, false, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 124,
                            columnNumber: 11
                        }, this),
                        cartItems.length > 0 && addresses.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-8 border-t border-gray-200 pt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-semibold text-gray-900 mb-4",
                                    children: "Delivery Address"
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 235,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative",
                                    ref: dropdownRef,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setIsAddressDropdownOpen(!isAddressDropdownOpen),
                                            className: "w-full p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-shadow text-left flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 min-w-0 flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                            className: "w-5 h-5 text-gray-400 mr-3 flex-shrink-0",
                                                            fill: "none",
                                                            stroke: "currentColor",
                                                            viewBox: "0 0 24 24",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                    lineNumber: 254,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                    lineNumber: 260,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 248,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm font-medium text-gray-900",
                                                            children: selectedAddress ? selectedAddress.address : "Select delivery address"
                                                        }, void 0, false, {
                                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                            lineNumber: 267,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 247,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    className: "w-5 h-5 text-gray-400 transition-transform ".concat(isAddressDropdownOpen ? "rotate-180" : ""),
                                                    fill: "none",
                                                    stroke: "currentColor",
                                                    viewBox: "0 0 24 24",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: 2,
                                                        d: "M19 9l-7 7-7-7"
                                                    }, void 0, false, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                        lineNumber: 281,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 273,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 240,
                                            columnNumber: 17
                                        }, this),
                                        isAddressDropdownOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-60 overflow-auto",
                                            children: [
                                                addresses.map((address)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        onClick: ()=>handleAddressSelect(address.id),
                                                        className: "p-4 hover:bg-gray-50 cursor-pointer transition-colors flex items-center ".concat(selectedAddressId === address.id ? "bg-blue-50 border-l-4 border-blue-500" : ""),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-5 h-5 text-gray-400 mr-3 flex-shrink-0",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: 2,
                                                                        d: "M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                        lineNumber: 308,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                        strokeLinecap: "round",
                                                                        strokeLinejoin: "round",
                                                                        strokeWidth: 2,
                                                                        d: "M15 11a3 3 0 11-6 0 3 3 0 016 0z"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                        lineNumber: 314,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                lineNumber: 302,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-sm font-medium text-gray-900 flex-1 min-w-0",
                                                                children: address.address
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                lineNumber: 321,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, address.id, true, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                        lineNumber: 293,
                                                        columnNumber: 23
                                                    }, this)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "border-t border-gray-200",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        href: "/account/addresses",
                                                        className: "p-4 hover:bg-gray-50 cursor-pointer transition-colors flex items-center text-blue-600 hover:text-blue-700",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                className: "w-5 h-5 mr-3 flex-shrink-0",
                                                                fill: "none",
                                                                stroke: "currentColor",
                                                                viewBox: "0 0 24 24",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    strokeWidth: 2,
                                                                    d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                    lineNumber: 339,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                lineNumber: 333,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "text-sm font-medium flex-1 min-w-0",
                                                                children: "Add new address"
                                                            }, void 0, false, {
                                                                fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                                lineNumber: 346,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                        lineNumber: 329,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                                    lineNumber: 328,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 291,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 239,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 234,
                            columnNumber: 13
                        }, this),
                        cartItems.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-8 border-t border-gray-200 pt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-semibold text-gray-900",
                                            children: "Total Items:"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 360,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-bold text-gray-900",
                                            children: selectedItemsData.reduce((total, item)=>total + quantities[item.idx], 0)
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 363,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 359,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-semibold text-gray-900",
                                            children: "Total Weight:"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 371,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-bold text-gray-900",
                                            children: [
                                                selectedItemsData.reduce((total, item)=>{
                                                    var _item_product;
                                                    const weight = (item === null || item === void 0 ? void 0 : (_item_product = item.product) === null || _item_product === void 0 ? void 0 : _item_product.weightPerUnit) ? Number(item.product.weightPerUnit) : 0;
                                                    const quantity = quantities[item.idx] || 0;
                                                    return total + weight * quantity;
                                                }, 0).toFixed(2),
                                                " ",
                                                "lbs"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 374,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 370,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-between items-center mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-semibold text-gray-900",
                                            children: "Total Cost:"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 388,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-lg font-bold text-gray-900",
                                            children: [
                                                "$",
                                                " ",
                                                selectedItemsData.reduce((total, item, idx)=>{
                                                    var _item_product;
                                                    const cost = (item === null || item === void 0 ? void 0 : (_item_product = item.product) === null || _item_product === void 0 ? void 0 : _item_product.pricePerUnit) ? Number(item.product.pricePerUnit) : 0;
                                                    const quantity = quantities[item.idx] || 0;
                                                    return total + cost * quantity;
                                                }, 0).toFixed(2)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 391,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 387,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-end space-x-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: "px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors",
                                            children: "Continue Shopping"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 405,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "submit",
                                            disabled: checkoutPending || selectedItems.size === 0,
                                            className: "px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors font-semibold disabled:opacity-50",
                                            children: checkoutPending ? "Processing..." : "Buy ".concat(selectedItems.size, " Item(s)")
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 411,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 404,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 358,
                            columnNumber: 13
                        }, this),
                        cartItems.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center py-12",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-gray-400 mb-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "mx-auto h-12 w-12",
                                        fill: "none",
                                        viewBox: "0 0 24 24",
                                        stroke: "currentColor",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 1,
                                            d: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
                                        }, void 0, false, {
                                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                            lineNumber: 432,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                        lineNumber: 426,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 425,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-lg font-medium text-gray-900 mb-2",
                                    children: "Your cart is empty"
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 440,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-gray-600",
                                    children: "Add some items to get started!"
                                }, void 0, false, {
                                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                                    lineNumber: 443,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                            lineNumber: 424,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
                    lineNumber: 106,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
            lineNumber: 101,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/dev/cs160project/food-delivery-system-cs160/app/(user)/checkout/checkoutItems.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_s(CheckoutComponent, "2KqBi4m0ZEgfNOj5KPO4SaBKaI4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$dev$2f$cs160project$2f$food$2d$delivery$2d$system$2d$cs160$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionState"]
    ];
});
_c = CheckoutComponent;
var _c;
__turbopack_context__.k.register(_c, "CheckoutComponent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=dev_cs160project_food-delivery-system-cs160_app_%28user%29_checkout_62e31a7a._.js.map