(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/dev_cs160project_food-delivery-system-cs160_08a39cc4._.js",
  "static/chunks/78f1f_b93f4a4f._.js"
],
    source: "dynamic"
});
